
/* 54 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var SingleStartPage = function () {
  function SingleStartPage(game) {
    _classCallCheck(this, SingleStartPage);

    this.game = game;
    this.model = this.game.gameModel;
    this.full2D = this.game.full2D;
    this.name = 'startPage';
  }

  _createClass(SingleStartPage, [{
    key: 'show',
    value: function show() {
      var _this = this;

      if (!this.full2D) {
        this.game.handleWxOnError({
          message: 'can not find full 2D',
          stack: ''
        });
      }
      setTimeout(function () {
        if (_this.full2D) {
          _this.full2D.showStartPage();
        } else {
          // wx.exitMiniProgram()
        }
      }, 0);
    }
  }, {
    key: 'hide',
    value: function hide() {
      this.full2D.hide2D();
    }
  }]);

  return SingleStartPage;
}();

exports.default = SingleStartPage;

/***/ }),