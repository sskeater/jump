
/* 16 */
/***/function (module, exports, __webpack_require__) {

	'use strict';

	var _window = __webpack_require__(1);

	var window = _interopRequireWildcard(_window);

	var _document = __webpack_require__(10);

	var _document2 = _interopRequireDefault(_document);

	var _util = __webpack_require__(8);

	function _interopRequireDefault(obj) {
		return obj && obj.__esModule ? obj : { default: obj };
	}

	function _interopRequireWildcard(obj) {
		if (obj && obj.__esModule) {
			return obj;
		} else {
			var newObj = {};if (obj != null) {
				for (var key in obj) {
					if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
				}
			}newObj.default = obj;return newObj;
		}
	}

	function _classCallCheck(instance, Constructor) {
		if (!(instance instanceof Constructor)) {
			throw new TypeError("Cannot call a class as a function");
		}
	}

	var TouchEvent = function TouchEvent(type) {
		_classCallCheck(this, TouchEvent);

		this.target = window.canvas;
		this.currentTarget = window.canvas;
		this.touches = [];
		this.targetTouches = [];
		this.changedTouches = [];
		this.preventDefault = _util.noop;
		this.stopPropagation = _util.noop;

		this.type = type;
	};

	function touchEventHandlerFactory(type) {
		return function (event) {
			var touchEvent = new TouchEvent(type);

			touchEvent.touches = event.touches;
			touchEvent.targetTouches = Array.prototype.slice.call(event.touches);
			touchEvent.changedTouches = event.changedTouches;
			touchEvent.timeStamp = event.timeStamp;
			_document2.default.dispatchEvent(touchEvent);
		};
	}

	wx.onTouchStart(touchEventHandlerFactory('touchstart'));
	wx.onTouchMove(touchEventHandlerFactory('touchmove'));
	wx.onTouchEnd(touchEventHandlerFactory('touchend'));
	wx.onTouchCancel(touchEventHandlerFactory('touchcancel'));

	/***/
},