
/* 52 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var SingleGameOverPage = function () {
  function SingleGameOverPage(game) {
    _classCallCheck(this, SingleGameOverPage);

    this.game = game;
    this.model = this.game.gameModel;
    this.full2D = this.game.full2D;
    this.name = 'singleSettlementPgae';
  }

  _createClass(SingleGameOverPage, [{
    key: 'show',
    value: function show() {
      var _this = this;

      var score = this.model.currentScore;
      var highest_score = this.model.getHighestScore();
      var start_time = this.model.startTime;
      var week_best_score = this.model.weekBestScore;
      var game_cnt = this.game.historyTimes.getTimes();
      if (!this.full2D) {
        this.game.handleWxOnError({
          message: 'can not find full 2D gameOverPage',
          stack: ''
        });
      }

      setTimeout(function () {
        if (_this.full2D) {
          _this.full2D.showGameOverPage({
            score: score,
            highest_score: highest_score,
            start_time: start_time,
            week_best_score: week_best_score,
            game_cnt: game_cnt
          });
        } else {
          // wx.exitMiniProgram()
        }
      }, 0);
    }
  }, {
    key: 'hide',
    value: function hide() {
      this.full2D.hide2D();
    }
  }]);

  return SingleGameOverPage;
}();

exports.default = SingleGameOverPage;

/***/ }),