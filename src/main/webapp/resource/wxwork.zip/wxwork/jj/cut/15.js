
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _queryCtrl = __webpack_require__(38);

var _queryCtrl2 = _interopRequireDefault(_queryCtrl);

var _modeCtrl = __webpack_require__(34);

var _modeCtrl2 = _interopRequireDefault(_modeCtrl);

var _networkCtrl = __webpack_require__(35);

var _networkCtrl2 = _interopRequireDefault(_networkCtrl);

var _animation = __webpack_require__(4);

var _config = __webpack_require__(2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var GameCtrl = function () {
  function GameCtrl(game) {
    _classCallCheck(this, GameCtrl);

    this.game = game;
  }

  _createClass(GameCtrl, [{
    key: 'init',
    value: function init() {
      this.gameView = this.game.gameView;
      this.queryCtrl = new _queryCtrl2.default(this.game);
      this.netWorkCtrl = new _networkCtrl2.default(this.game);
      this.modeCtrl = new _modeCtrl2.default(this.game);
      this.model = this.game.gameModel;

      this.reporter = this.game.reporter;
      this.historyTimes = this.game.historyTimes;
      this.viewer = this.game.viewer;
    }
  }, {
    key: 'firstInitGame',
    value: function firstInitGame(options) {
      this.queryCtrl.identifyMode(options);
      this.modeCtrl.initFirstPage(options);
    }
  }, {
    key: 'identifyModeErr',
    value: function identifyModeErr(wording) {
      this.gameView.showIdentifyModeErr(wording);
    }
  }, {
    key: 'onLoginSuccess',
    value: function onLoginSuccess() {
      this.reporter.setTimer(_config.REPORTERTIMEOUT);
    }

    // 首页：开始游戏

  }, {
    key: 'clickStart',
    value: function clickStart() {
      this.modeCtrl.clickStart();
    }

    // 首页：点击排行

  }, {
    key: 'showFriendRank',
    value: function showFriendRank() {
      this.modeCtrl.showFriendRank();
    }

    // 结算页：点击排行

  }, {
    key: 'clickRank',
    value: function clickRank() {
      this.modeCtrl.clickRank();
    }
  }, {
    key: 'gameOver',
    value: function gameOver(score) {
      this.model.setScore(score);
      if (this.model.mode != 'observe') {
        var highestScore = this.model.getHighestScore();
        var weekBestScore = this.model.weekBestScore;

        // 加一局玩过的次数
        this.historyTimes.addOne();
        var gameTimes = this.historyTimes.getTimes();

        this.reporter.playGameReport(score, highestScore, gameTimes);
        //console.log("wtf", JSON.stringify(this.game.actionList), JSON.stringify(this.game.musicList), this.game.randomSeed,  JSON.stringify(this.game.touchList));
        // !!! 这里因为调用的都是同一个接口，为了节省服务器资源，最高分跟回合次数耦合在一起了
        if (weekBestScore < score) {
          // 如果产生了最高分
          // !!! 这里上传了最高分和历史回合次数
          var verifyData = {
            seed: this.game.randomSeed,
            action: this.game.actionList,
            musicList: this.game.musicList,
            touchList: this.game.touchList,
            version: 1
          };
          this.historyTimes.upLoadHistoryTimes(score, verifyData);
          // this.model.weekBestScore = score
          // if (highestScore < score) {
          //   this.model.saveHeighestScore(score)
          // }
        } else {

          // 检查是否需要上传次数
          this.historyTimes.checkUp();
        }

        // 更新排行榜分数
        this.netWorkCtrl.upDateFriendsScoreList();
      }

      if (this.mode == 'player') {
        this.reporter.playAudienceReport();
      }

      if (this.mode == 'battle') {
        this.reporter.playPKReport(score);
      }
    }
  }, {
    key: 'gameOverShowPage',
    value: function gameOverShowPage() {
      this.modeCtrl.showGameOverPage();
      if (this.model.mode != 'observe') {
        if (this.model.currentScore >= this.model.weekBestScore) {
          this.model.weekBestScore = this.model.currentScore;
          this.model.saveWeekBestScore(this.model.currentScore);
          if (this.model.currentScore > this.model.getHighestScore()) {
            var verifyData = {
              seed: this.game.randomSeed,
              action: this.game.actionList
            };
            this.model.saveHeighestScore(this.model.currentScore, verifyData);
          }
        }
      }
    }

    // 结算页面：重新玩

  }, {
    key: 'clickReplay',
    value: function clickReplay() {
      this.reporter.playAudienceReportStart();
      this.modeCtrl.gameOverClickReplay();
    }

    // 好友排行：返回上一页

  }, {
    key: 'friendRankReturn',
    value: function friendRankReturn() {
      this.modeCtrl.friendRankReturn();
    }
  }, {
    key: 'netWorkLogin',
    value: function netWorkLogin() {
      this.netWorkCtrl.netWorkLogin();
    }

    // 好友排行页面：群分享

  }, {
    key: 'shareGroupRank',
    value: function shareGroupRank() {
      this.modeCtrl.shareGroupRank();
    }
  }, {
    key: 'afterShareGroupRank',
    value: function afterShareGroupRank(success, isGroup) {
      // console.log(success, isGroup)
      this.reporter.shareGroupReport(isGroup);
    }

    // 结算页面：

  }, {
    key: 'shareBattleCard',
    value: function shareBattleCard() {
      this.modeCtrl.shareBattleCard();
    }
  }, {
    key: 'afterShareBattle',
    value: function afterShareBattle(success, isGroup) {
      // console.log(success, isGroup)
      if (success) {
        this.reporter.sharePKReport(isGroup);
      }
    }
  }, {
    key: 'groupPlayGame',
    value: function groupPlayGame() {
      this.modeCtrl.groupPlayGame();
    }

    // 加入挑战模式事件

  }, {
    key: 'loginBattle',
    value: function loginBattle(isGroup) {
      // console.log('loginBattle', isGroup)
      this.reporter.joinPKReport(isGroup);
      this.reporter.playPKReportStart(isGroup);
    }

    // 获取PK的信息之后触发事件

  }, {
    key: 'showPkPage',
    value: function showPkPage(ownerScore) {
      // console.log('showPkPage', ownerScore)
      this.reporter.playPKScore(ownerScore);
    }

    // 挑战页面：点击挑战

  }, {
    key: 'onBattlePlay',
    value: function onBattlePlay(pk) {
      this.modeCtrl.battlePlay(pk);
    }
  }, {
    key: 'battleToSingle',
    value: function battleToSingle() {
      this.reporter.resetPKReport();
    }

    // 事件

  }, {
    key: 'shareObservCard',
    value: function shareObservCard() {
      this.modeCtrl.shareObservCard();
    }
  }, {
    key: 'socketJoinSuccess',
    value: function socketJoinSuccess(success) {
      this.modeCtrl.socketJoinSuccess(success);
      if (this.model.mode == 'observe') {
        if (success) {
          this.game.socketFirstSync = true;
          this.reporter.joinAudienceReportStart();
        }
      } else {
        this.reporter.joinAudienceReport();
      }

      if (this.model.mode == 'player') {
        this.reporter.playAudienceReportStart();
      }
    }

    // 分享卡片之后

  }, {
    key: 'afterShareObserveCard',
    value: function afterShareObserveCard(isGroup) {
      this.reporter.shareAudienceReport(isGroup);
    }
  }, {
    key: 'showPlayerGG',
    value: function showPlayerGG(data) {
      this.modeCtrl.showPlayerGG(data);
    }
  }, {
    key: 'showPlayerWaiting',
    value: function showPlayerWaiting() {
      this.modeCtrl.showPlayerWaiting();
    }
  }, {
    key: 'onPlayerOut',
    value: function onPlayerOut() {
      this.modeCtrl.onPlayerOut();
    }
  }, {
    key: 'onViewerStart',
    value: function onViewerStart() {
      this.game.audioManager.scale_intro.stop();
      if (this.game.deadTimeout) {
        clearTimeout(this.game.deadTimeout);
        this.game.deadTimeout = null;
      }
      this.game.pendingReset = false;
      // TweenAnimation.killAll();
      this.modeCtrl.onViewerStart();
      this.reporter.joinAudienceReport();
    }
  }, {
    key: 'wxOnShow',
    value: function wxOnShow(options) {
      var _this = this;

      this.netWorkCtrl.requestServerInit();
      this.reporter.setTimer(_config.REPORTERTIMEOUT);
      setTimeout(function () {

        // 根据传进来的mode参数判断，如果有mode说明需要更换场景
        if (!!options.query && options.query.hasOwnProperty('mode')) {
          _this.modeCtrl.reInitFirstPage(options);
        } else if (_this.model.mode != 'single' && _this.model.mode != 'player' && _this.model.mode != 'battle') {
          // 进来没有参数onshow，单人，围观，挑战，有可能在分享时候回来
          _this.modeCtrl.changeMode('singleCtrl');
        }
      }, 300);
    }
  }, {
    key: 'wxOnhide',
    value: function wxOnhide() {
      this.reporter.quitReport();
      if (this.model.mode == 'observe') {
        this.reporter.joinAudienceReport();
      }

      // 清除定时器，1、服务器下发配置的定时器，2、上报的定时器
      this.netWorkCtrl.clearServerInit();
      this.reporter.clearTimer();

      this.modeCtrl.wxOnhide();
    }
  }, {
    key: 'onReplayGame',
    value: function onReplayGame() {
      var mode = this.model.mode;
      if (mode != 'observe') {
        this.reporter.playGameReportStart();
      }
    }
  }, {
    key: 'onPeopleCome',
    value: function onPeopleCome(data) {
      if (data.audience_cmd == 0) {

        // 来人了
        this.viewer.peopleCome(data);
        this.reporter.playAudienceReportMaxPeople(this.viewer.num);
      } else if (data.audience_cmd == 1) {

        // 人走了
        this.viewer.peopleOut(data);
      }
    }
  }, {
    key: 'onServerConfigForbid',
    value: function onServerConfigForbid() {}
  }, {
    key: 'onSocketCloseErr',
    value: function onSocketCloseErr() {
      this.gameView.showSocketCloseErr();
      this.modeCtrl.changeMode('singleCtrl');
    }
  }]);

  return GameCtrl;
}();

exports.default = GameCtrl;

/***/ }),