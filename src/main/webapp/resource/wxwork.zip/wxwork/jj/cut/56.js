
/* 56 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Friction = function () {
  /***
   * Friction physics simulation. Friction is actually just a simple
   * power curve; the only trick is taking the natural log of the
   * initial drag so that we can express the answer in terms of time.
   */
  function Friction(drag) {
    _classCallCheck(this, Friction);

    this._drag = drag;
    this._dragLog = Math.log(drag);
    this._x = 0;
    this._v = 0;
    this._startTime = 0;
  }

  _createClass(Friction, [{
    key: "set",
    value: function set(x, v) {
      this._x = x;
      this._v = v;
      this._startTime = new Date().getTime();
    }
  }, {
    key: "x",
    value: function x(dt) {
      if (dt === undefined) dt = (new Date().getTime() - this._startTime) / 1000;
      var powDragDt;
      if (dt === this._dt && this._powDragDt) {
        powDragDt = this._powDragDt;
      } else {
        powDragDt = this._powDragDt = Math.pow(this._drag, dt);
      }
      this._dt = dt;
      return this._x + this._v * powDragDt / this._dragLog - this._v / this._dragLog;
    }
  }, {
    key: "dx",
    value: function dx(dt) {
      if (dt === undefined) dt = (new Date().getTime() - this._startTime) / 1000;
      var powDragDt;
      if (dt === this._dt && this._powDragDt) {
        powDragDt = this._powDragDt;
      } else {
        powDragDt = this._powDragDt = Math.pow(this._drag, dt);
      }
      this._dt = dt;
      return this._v * powDragDt;
    }
  }, {
    key: "done",
    value: function done() {
      return Math.abs(this.dx()) < 3;
    }
  }]);

  return Friction;
}();

exports.default = Friction;

/***/ }),