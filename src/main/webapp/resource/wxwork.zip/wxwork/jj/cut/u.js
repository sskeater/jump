
/* 20 */
/***/function (module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	function _classCallCheck(instance, Constructor) {
		if (!(instance instanceof Constructor)) {
			throw new TypeError("Cannot call a class as a function");
		}
	}

	/*
  * TODO 使用 wx.readFile 来封装 FileReader
  */
	var FileReader = function FileReader() {
		_classCallCheck(this, FileReader);
	};

	exports.default = FileReader;

	/***/
},