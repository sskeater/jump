
/* 8 */
/***/function (module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.noop = noop;
	function noop() {}

	/***/
},