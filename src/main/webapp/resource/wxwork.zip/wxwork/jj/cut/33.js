
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _groupPage = __webpack_require__(44);

var _groupPage2 = _interopRequireDefault(_groupPage);

var _network = __webpack_require__(3);

var _network2 = _interopRequireDefault(_network);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var GroupShareCtrl = function () {
  function GroupShareCtrl(game, modeCtrl) {
    _classCallCheck(this, GroupShareCtrl);

    this.name = 'groupShare';
    this.game = game;
    this.gameCtrl = this.game.gameCtrl;
    this.model = this.game.gameModel;
    this.view = this.game.gameView;
    this.netWorkCtrl = this.gameCtrl.netWorkCtrl;
    this.modeCtrl = modeCtrl;
    this.groupPage = new _groupPage2.default(game);

    this.shareTicket = '';
    this.shareInfoTimeout = null;
  }

  _createClass(GroupShareCtrl, [{
    key: 'init',
    value: function init(options) {
      // console.log('init groupShareCtrl')
      // 服务器
      var serverConfig = this.model.getServerConfig();
      if (serverConfig) {
        if (!serverConfig.group_score_switch) {
          this.view.showServeConfigForbiddenGroupShare();
          this.modeCtrl.changeMode('singleCtrl');
          return;
        }
      }
      this.model.setStage('');
      var sessionId = this.model.getSessionId();
      this.shareTicket = options.shareTicket;
      wx.showLoading();
      if (!sessionId) {
        this.netWorkCtrl.netWorkLogin(this.afterLogin.bind(this));
      } else {
        this.afterLogin(true);
      }
    }
  }, {
    key: 'afterLogin',
    value: function afterLogin(success) {
      var _this = this;

      if (success) {
        this.setShareInfoTimeout();
        // 换取rawdata
        wx.getShareInfo({
          shareTicket: this.shareTicket,
          success: function success(res) {

            // 如果定时器还没有触发，就取消定时器
            if (_this.shareInfoTimeout != null) {
              _this.clearShareInfoTimeout();
              // console.log('没有触发定时器')
            } else {
              // console.log('已经触发定时器')
              return;
            }

            _this.model.setShareTicket(res.rawData);

            // 获取群数据
            _network2.default.getGroupScore(function (success, res) {

              // 如果成功则显示好友排行
              if (success) {
                var list = res.data.user_info || [];
                var myUserInfo = res.data.my_user_info || {};
                _this.showGroupRankPage(list, myUserInfo);
              } else {

                // 如果失败，回到单机模式
                // this.handleNetworkFucked(true, '数据异常，点击确定进入游戏')
                _this.goToGroupShareFail();
              }
              wx.hideLoading();
            });
          },
          fail: function fail(res) {

            // 如果定时器还没有触发，就取消定时器
            if (_this.shareInfoTimeout != null) {
              _this.clearShareInfoTimeout();
              // console.log('没有触发定时器')
            } else {
              // console.log('已经触发定时器')
              return;
            }

            wx.hideLoading();
            _this.goToGroupShareFail('群里的群分享才有效哦~');
            // this.handleNetworkFucked(true, '数据异常，点击确定进入游戏')
          }
        });
      } else {
        wx.hideLoading();
        this.goToGroupShareFail();
      }
    }
  }, {
    key: 'setShareInfoTimeout',
    value: function setShareInfoTimeout() {
      this.shareInfoTimeout = setTimeout(this.handleShareInfoTimeout.bind(this), 5000);
    }
  }, {
    key: 'clearShareInfoTimeout',
    value: function clearShareInfoTimeout() {
      if (this.shareInfoTimeout != null) {
        clearTimeout(this.shareInfoTimeout);
        this.shareInfoTimeout = null;
      }
    }
  }, {
    key: 'handleShareInfoTimeout',
    value: function handleShareInfoTimeout() {
      this.clearShareInfoTimeout();
      this.goToGroupShareFail();
    }
  }, {
    key: 'goToGroupShareFail',
    value: function goToGroupShareFail(wording) {
      this.view.showGroupShareFail(wording);
      this.modeCtrl.changeMode('singleCtrl');
    }
  }, {
    key: 'showGroupRankPage',
    value: function showGroupRankPage(list, myUserInfo) {
      this.groupPage.show(list, myUserInfo);
      this.model.setStage(this.groupPage.name);
      this.currentPage = this.groupPage;
    }
  }, {
    key: 'destroy',
    value: function destroy() {
      wx.hideLoading();
      if (this.currentPage) {
        this.currentPage.hide();
      }
      this.model.setStage('');
      this.shareTicket = '';
      this.model.clearShareTicket();
      this.clearShareInfoTimeout();
      this.game.resetScene();
    }
  }, {
    key: 'groupPlayGame',
    value: function groupPlayGame() {
      this.modeCtrl.directPlaySingleGame();
    }
  }, {
    key: 'wxOnhide',
    value: function wxOnhide() {
      return;
    }
  }]);

  return GroupShareCtrl;
}();

exports.default = GroupShareCtrl;

/***/ }),