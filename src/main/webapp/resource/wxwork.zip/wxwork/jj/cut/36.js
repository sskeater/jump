
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _observeWaiting = __webpack_require__(48);

var _observeWaiting2 = _interopRequireDefault(_observeWaiting);

var _observeGg = __webpack_require__(46);

var _observeGg2 = _interopRequireDefault(_observeGg);

var _observeOut = __webpack_require__(47);

var _observeOut2 = _interopRequireDefault(_observeOut);

var _network = __webpack_require__(3);

var _network2 = _interopRequireDefault(_network);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var SYCTIME = 10000;
var TIMEOUT = 9000;

var ObserveCtrl = function () {
  function ObserveCtrl(game, modeCtrl) {
    _classCallCheck(this, ObserveCtrl);

    this.game = game;
    this.name = 'observe';
    this.gameCtrl = this.game.gameCtrl;
    this.model = this.game.gameModel;
    this.view = this.game.gameView;
    this.modeCtrl = modeCtrl;
    this.netWorkCtrl = this.gameCtrl.netWorkCtrl;
    this.gameSocket = this.game.gameSocket;
    this.currentPage = null;

    this.waitingPage = new _observeWaiting2.default(game);
    this.ggPage = new _observeGg2.default(game);
    this.outPage = new _observeOut2.default(game);

    this.gameId = '';
    this.longTimeout = null;
  }

  _createClass(ObserveCtrl, [{
    key: 'init',
    value: function init(options) {
      // TODO 如果服务器下发的配置禁止围观，返回单机游戏
      var serverConfig = this.model.getServerConfig();
      if (serverConfig) {
        if (!serverConfig.audience_mode_switch) {
          this.view.showServeConfigForbiddenObserveMode();
          this.modeCtrl.changeMode('singleCtrl');
          return;
        }
      }
      this.model.setStage('');
      var sessionId = this.model.getSessionId();
      this.gameId = options.query.gameId;
      this.model.setObserveInfo({
        headimg: options.query.headimg,
        nickName: options.query.nickName
      });
      this.model.setGameId(this.gameId);

      wx.showLoading();
      if (!sessionId) {
        this.netWorkCtrl.netWorkLogin(this.afterLogin.bind(this));
      } else {
        this.afterLogin(true);
      }
    }
  }, {
    key: 'afterLogin',
    value: function afterLogin(success) {
      if (success) {
        this.setLongTimeHandle();
        this.gameSocket.connectSocket();
        this.model.setStage('');
      } else {
        this.goToObserveStateFail();
      }
    }
  }, {
    key: 'socketJoinSuccess',
    value: function socketJoinSuccess(success) {

      // 清除定时器
      this.clearLongTimeHandle();
      wx.hideLoading();
      if (success) {

        // 切换页面
        this.waitingPage.show();
        this.model.setStage(this.waitingPage.name);
        this.currentPage = this.waitingPage;

        // 清UI分数
        this.game.UI.setScore(0);

        // 设置轮询，查主播状态
        this.checkPlayerTimeout = setInterval(this.checkPlayerState.bind(this), SYCTIME);
      } else {

        // 展示主播直播结束
        this.showPlayerDead();
      }
    }
  }, {
    key: 'goToObserveStateFail',
    value: function goToObserveStateFail() {

      // 提示wording
      this.view.showObserveStateFail();

      // 跳回单机主页
      this.modeCtrl.changeMode('singleCtrl');
    }
  }, {
    key: 'setLongTimeHandle',
    value: function setLongTimeHandle() {
      this.longTimeout = setTimeout(this.handleLongTime.bind(this), TIMEOUT);
    }
  }, {
    key: 'handleLongTime',
    value: function handleLongTime() {
      this.goToObserveStateFail();
    }
  }, {
    key: 'clearLongTimeHandle',
    value: function clearLongTimeHandle() {
      if (this.longTimeout != null) {
        clearTimeout(this.longTimeout);
        this.longTimeout = null;
      }
    }
  }, {
    key: 'showPlayerDead',
    value: function showPlayerDead() {
      // 关闭socket
      this.gameSocket.close();

      // 关闭定时器
      this.clearCheckPlayerTimeout();

      // 展示主播退出页面
      if (this.currentPage) {
        this.currentPage.hide();
      }
      this.outPage.show();
      this.model.setStage(this.outPage.name);
      this.currentPage = this.outPage;
    }
  }, {
    key: 'checkPlayerState',
    value: function checkPlayerState() {
      _network2.default.syncop(this.judgePlayerState.bind(this));
    }
  }, {
    key: 'judgePlayerState',
    value: function judgePlayerState(success, res) {
      if (success) {
        if (res.data.state != 0) {
          this.clearCheckPlayerTimeout();
          this.showPlayerDead();
        }
      } else {
        this.handleSyncopErr();
      }
    }
  }, {
    key: 'handleSyncopErr',
    value: function handleSyncopErr() {
      this.view.showSyncopErr();
      this.goToObserveStateFail();
    }
  }, {
    key: 'clearCheckPlayerTimeout',
    value: function clearCheckPlayerTimeout() {
      if (this.checkPlayerTimeout != null) {
        clearInterval(this.checkPlayerTimeout);
        this.checkPlayerTimeout = null;
      }
    }
  }, {
    key: 'destroy',
    value: function destroy() {
      if (this.currentPage) {
        this.currentPage.hide();
      }
      this.currentPage = null;
      this.model.setStage('');

      // 清理gameID
      this.model.clearGameId();

      // 清理连接超时定时器
      this.clearLongTimeHandle();

      // 清理sycop定时器
      this.clearCheckPlayerTimeout();

      // 隐藏loading
      wx.hideLoading();

      if (this.gameSocket.alive) {

        // 关闭socket
        this.gameSocket.close();
      }

      // 清楚围观者的信息
      this.model.clearObserveInfo();

      this.game.instructionCtrl.destroy();

      this.game.resetScene();
    }
  }, {
    key: 'showPlayerWaiting',
    value: function showPlayerWaiting() {
      // 查看当前stage是否是playerWaiting，不是才改
      if (this.currentPage != this.waitingPage) {
        if (this.currentPage != null) {
          this.currentPage.hide();
        }
        this.waitingPage.show();
        this.model.setStage(this.waitingPage.name);
        this.currentPage = this.waitingPage;
      }
    }
  }, {
    key: 'showPlayerGG',
    value: function showPlayerGG(score) {
      if (this.currentPage != null) {
        this.currentPage.hide();
      }
      this.ggPage.show(score);
      this.model.setStage(this.ggPage.name);
      this.currentPage = this.ggPage;
    }
  }, {
    key: 'onPlayerOut',
    value: function onPlayerOut() {
      this.showPlayerDead();
    }
  }, {
    key: 'onViewerStart',
    value: function onViewerStart() {
      this.gameSocket.quitObserve();
      this.game.instructionCtrl.destroy();
      this.modeCtrl.directPlaySingleGame();
    }
  }, {
    key: 'showGameOverPage',
    value: function showGameOverPage() {
      return;
    }
  }, {
    key: 'wxOnhide',
    value: function wxOnhide() {
      this.clearCheckPlayerTimeout();
      this.gameSocket.quitObserve();
      this.gameSocket.close();
      this.game.resetScene();
    }
  }, {
    key: 'wxOnshow',
    value: function wxOnshow() {
      return;
    }
  }]);

  return ObserveCtrl;
}();

exports.default = ObserveCtrl;

/***/ }),