
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _singleCtrl = __webpack_require__(10);

var _singleCtrl2 = _interopRequireDefault(_singleCtrl);

var _groupShareCtrl = __webpack_require__(33);

var _groupShareCtrl2 = _interopRequireDefault(_groupShareCtrl);

var _battleCtrl = __webpack_require__(32);

var _battleCtrl2 = _interopRequireDefault(_battleCtrl);

var _observeCtrl = __webpack_require__(36);

var _observeCtrl2 = _interopRequireDefault(_observeCtrl);

var _playerCtrl = __webpack_require__(37);

var _playerCtrl2 = _interopRequireDefault(_playerCtrl);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var ModeCtrl = function () {
  function ModeCtrl(game) {
    _classCallCheck(this, ModeCtrl);

    this.game = game;
    this.singleCtrl = new _singleCtrl2.default(game, this);
    this.groupShareCtrl = new _groupShareCtrl2.default(game, this);
    this.battleCtrl = new _battleCtrl2.default(game, this);
    this.observeCtrl = new _observeCtrl2.default(game, this);
    this.playerCtrl = new _playerCtrl2.default(game, this);

    this.model = game.gameModel;
    this.gameCtrl = game.gameCtrl;
    this.currentCtrl = null;
  }

  _createClass(ModeCtrl, [{
    key: 'initFirstPage',
    value: function initFirstPage(options) {
      var mode = this.model.getMode();
      switch (mode) {
        case 'single':
          this.currentCtrl = this.singleCtrl;
          this.singleCtrl.init(options);
          this.gameCtrl.netWorkLogin();
          break;
        case 'groupShare':
          this.currentCtrl = this.groupShareCtrl;
          this.groupShareCtrl.init(options);
          break;
        case 'battle':
          this.currentCtrl = this.battleCtrl;
          this.battleCtrl.init(options);
          break;
        case 'observe':
          this.currentCtrl = this.observeCtrl;
          this.observeCtrl.init(options);
          break;

        default:
          this.currentCtrl = this.singleCtrl;
          this.model.setMode('single');
          this.singleCtrl.init(options);
          this.gameCtrl.netWorkLogin();
          // console.log('!!!!!!!!!!!!!!!!!!!!!!!!!!!')
          // console.log('InitFirstPage 找不到对应mode')
          // console.log('!!!!!!!!!!!!!!!!!!!!!!!!!!!')
          break;
      }
    }
  }, {
    key: 'reInitFirstPage',
    value: function reInitFirstPage(options) {
      if (this.currentCtrl) {
        this.currentCtrl.destroy();
        this.currentCtrl = null;
      }
      this.gameCtrl.queryCtrl.identifyMode(options);
      this.initFirstPage(options);
    }
  }, {
    key: 'clickStart',
    value: function clickStart() {
      if (this.currentCtrl) {
        if (this.currentCtrl.clickStart) {
          this.currentCtrl.clickStart();
        }
      }
    }
  }, {
    key: 'showGameOverPage',
    value: function showGameOverPage() {
      if (this.currentCtrl) {
        if (this.currentCtrl.showGameOverPage) {
          this.currentCtrl.showGameOverPage();
        }
      }
    }
  }, {
    key: 'gameOverClickReplay',
    value: function gameOverClickReplay() {
      if (this.currentCtrl) {
        if (this.currentCtrl.gameOverClickReplay) {
          this.currentCtrl.gameOverClickReplay();
        } else {
          this.game.handleWxOnError({
            message: 'cannot Find this.currentCtrl.gameOverClickReplay',
            stack: this.game.mode + '' + this.game.stage
          });
        }
      }
    }
  }, {
    key: 'showFriendRank',
    value: function showFriendRank() {
      if (this.currentCtrl) {
        if (this.currentCtrl.showFriendRank) {
          this.currentCtrl.showFriendRank();
        }
      }
    }
  }, {
    key: 'friendRankReturn',
    value: function friendRankReturn() {
      if (this.currentCtrl) {
        if (this.currentCtrl.friendRankReturn) {
          this.currentCtrl.friendRankReturn();
        }
      }
    }
  }, {
    key: 'shareGroupRank',
    value: function shareGroupRank() {
      if (this.currentCtrl) {
        if (this.currentCtrl.shareGroupRank) {
          this.currentCtrl.shareGroupRank();
        }
      }
    }
  }, {
    key: 'clickRank',
    value: function clickRank() {
      if (this.currentCtrl) {
        if (this.currentCtrl.clickRank) {
          this.currentCtrl.clickRank();
        }
      }
    }
  }, {
    key: 'shareBattleCard',
    value: function shareBattleCard() {
      if (this.currentCtrl) {
        if (this.currentCtrl.shareBattleCard) {
          this.currentCtrl.shareBattleCard();
        }
      }
    }
  }, {
    key: 'changeMode',
    value: function changeMode(name) {
      if (this.currentCtrl) {
        if (this.currentCtrl.destroy) {
          this.currentCtrl.destroy();
        }
      }
      this.model.setMode(this[name].name);
      this.currentCtrl = this[name];
      this[name].init();
    }
  }, {
    key: 'singleChangeToPlayer',
    value: function singleChangeToPlayer() {
      // 因为是单机转主播，所以不需要hide
      this.model.setMode(this.playerCtrl.name);
      this.currentCtrl = this.playerCtrl;
      this.playerCtrl.init();
    }
  }, {
    key: 'groupPlayGame',
    value: function groupPlayGame() {
      if (this.currentCtrl) {
        if (this.currentCtrl.groupPlayGame) {
          this.currentCtrl.groupPlayGame();
        }
      }
    }
  }, {
    key: 'directPlaySingleGame',
    value: function directPlaySingleGame() {
      if (this.currentCtrl) {
        this.currentCtrl.destroy();
      }
      this.model.setMode(this.singleCtrl.name);
      this.currentCtrl = this.singleCtrl;
      this.singleCtrl.clickStart();
    }
  }, {
    key: 'battlePlay',
    value: function battlePlay(pk) {
      if (this.currentCtrl) {
        if (this.currentCtrl.battlePlay) {
          this.currentCtrl.battlePlay(pk);
        }
      }
    }
  }, {
    key: 'shareObservCard',
    value: function shareObservCard() {
      if (this.currentCtrl) {
        if (this.currentCtrl.shareObservCard) {
          this.currentCtrl.shareObservCard();
        }
      }
    }
  }, {
    key: 'socketJoinSuccess',
    value: function socketJoinSuccess(success) {
      if (this.currentCtrl) {
        if (this.currentCtrl.socketJoinSuccess) {
          this.currentCtrl.socketJoinSuccess(success);
        }
      }
    }
  }, {
    key: 'showPlayerGG',
    value: function showPlayerGG(data) {
      if (this.currentCtrl) {
        if (this.currentCtrl.showPlayerGG) {
          this.currentCtrl.showPlayerGG(data);
        }
      }
    }
  }, {
    key: 'showPlayerWaiting',
    value: function showPlayerWaiting() {
      if (this.currentCtrl) {
        if (this.currentCtrl.showPlayerWaiting) {
          this.currentCtrl.showPlayerWaiting();
        }
      }
    }
  }, {
    key: 'onPlayerOut',
    value: function onPlayerOut() {
      if (this.currentCtrl) {
        if (this.currentCtrl.onPlayerOut) {
          this.currentCtrl.onPlayerOut();
        } else {
          this.game.handleWxOnError({
            message: 'cannot Find this.currentCtrl.onPlayerOut',
            stack: this.game.mode + '' + this.game.stage
          });
        }
      }
    }
  }, {
    key: 'onViewerStart',
    value: function onViewerStart() {
      if (this.currentCtrl) {
        if (this.currentCtrl.onViewerStart) {
          this.currentCtrl.onViewerStart();
        }
      }
    }
  }, {
    key: 'wxOnhide',
    value: function wxOnhide() {
      if (this.currentCtrl) {
        if (this.currentCtrl.wxOnhide) {
          this.currentCtrl.wxOnhide();
        }
      }
    }
  }]);

  return ModeCtrl;
}();

exports.default = ModeCtrl;

/***/ }),