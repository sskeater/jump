
/* 9 */
/***/function (module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = Canvas;

	var _constructor = __webpack_require__(3);

	var _HTMLElement = __webpack_require__(4);

	var _HTMLElement2 = _interopRequireDefault(_HTMLElement);

	var _document = __webpack_require__(10);

	var _document2 = _interopRequireDefault(_document);

	function _interopRequireDefault(obj) {
		return obj && obj.__esModule ? obj : { default: obj };
	}

	var hasModifiedCanvasPrototype = false;
	var hasInit2DContextConstructor = false;
	var hasInitWebGLContextConstructor = false;

	function Canvas() {
		var canvas = wx.createCanvas();

		canvas.type = 'canvas';

		canvas.__proto__.__proto__ = new _HTMLElement2.default('canvas');

		var _getContext = canvas.getContext;

		canvas.getBoundingClientRect = function () {
			var ret = {
				top: 0,
				left: 0,
				width: window.innerWidth,
				height: window.innerHeight
			};
			return ret;
		};

		return canvas;
	}

	/***/
},