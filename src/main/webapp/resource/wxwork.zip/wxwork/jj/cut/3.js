
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _session = __webpack_require__(6);

var _session2 = _interopRequireDefault(_session);

var _storage = __webpack_require__(5);

var _storage2 = _interopRequireDefault(_storage);

var _encryption = __webpack_require__(59);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * 配置目前有：
 * {
 *  audience_mode_switch:0, // 围观模式，围观在前端拦截
 *  friends_score_switch:0,
 *  group_score_switch:0,
 *  game_center_entry_switch, // 目前没有
 *  bad_js_ratio
 * }
 */

var networkConfig = {
  // AJAX_URL: 'https://wxardm.weixin.qq.com',
  AJAX_URL: 'https://mp.weixin.qq.com'
};

var Network = function () {
  function Network() {
    _classCallCheck(this, Network);
  }

  _createClass(Network, null, [{
    key: 'onServerConfigForbid',
    value: function onServerConfigForbid(cb) {
      this.emmitServerConfigForbid = cb;
    }
  }, {
    key: 'getUserInfo',
    value: function getUserInfo() {
      var obj = {
        base_req: {
          session_id: _session2.default.sessionId,
          fast: 1
        }
      };

      wx.request({
        url: networkConfig.AJAX_URL + '/wxagame/wxagame_getuserinfo',
        method: 'POST',
        data: obj,
        success: function success(res) {
          if (res.statusCode !== 200) {
            // // console.log('Network getUserInfo not ok', res)
            return;
          }

          // 当sessionId过期的逻辑 待测
          // if (res.data.base_resp.errcode === -5) {

          //   this.reGetSessionId('getUserInfo')
          //   return
          // }

          if (res.data.base_resp.errcode !== 0) {
            // console.log('Network getUserInfo not ok', res)
            return;
          }

          // console.log('Network getUserInfo success', res)
          _storage2.default.saveMyUserInfo(res.data);
        },
        fail: function fail(err) {
          // console.log('Network getUserInfo fail', err)
        }
      });
    }
  }, {
    key: 'requestLogin',
    value: function requestLogin(afterLoginProcess) {
      if (!afterLoginProcess) {
        afterLoginProcess = function afterLoginProcess() {
          // console.log('Network requestLogin parameter')
        };
      }
      wx.login({
        success: function success(res) {
          if (res.code) {
            // console.log('Network login ok', res.code)

            // 存session
            _session2.default.setLoginState(res.code);

            // 存sessionId到缓存里
            // Storage.saveSessionId(res.code)
            afterLoginProcess(true);
          } else {
            // console.log('Network wx.login fail', res)
            afterLoginProcess(false);
          }
        },
        fail: function fail(res) {

          // 处理失败逻辑
          // console.log('Network wx.login fail: ', res)
          afterLoginProcess(false);
        }
      });
    }
  }, {
    key: 'requestFriendsScore',
    value: function requestFriendsScore() {
      var callback = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : function () {};

      if (_session2.default.serverConfig) {
        if (!_session2.default.serverConfig.friends_score_switch) {
          // console.log('Network requestFriendsScore server forbidden')
          // this.errHandler()
          return;
        }
      }

      if (!_session2.default.sessionId) {
        // console.log('Network requestFriendsScore abort for no sessionId')
        callback(false);
        return;
      }
      var obj = {
        base_req: {
          session_id: _session2.default.sessionId,
          fast: 1
        }

        // 数据格式 testData = {
        //   user_info: [
        //     {
        //       nickname: 'juto',
        //       headimg: 'http://wx.qlogo.cn/mmhead/qE9MKluetOlFQg1u4bfs14LFdlRu2MSFKzj5iceWeia4ibZCngaibibE1NQ/0',
        //       score_info: [
        //         {type: 0, score: 1000}
        //       ],
        //     }
        //   ]
        // }
      };wx.request({
        url: networkConfig.AJAX_URL + '/wxagame/wxagame_getfriendsscore',
        method: 'POST',
        data: obj,
        success: function success(res) {
          if (res.statusCode !== 200) {
            // console.log('Network getfriendsscore not ok', res)
            if (callback) {
              callback(false);
            }
            return;
          }

          // 当sessionId过期的逻辑 待测
          // if (res.data.base_resp.errcode === -5) {
          //   this.reGetSessionId('requestFriendsScore', callback)
          //   return
          // }

          if (res.data.base_resp.errcode !== 0) {
            // console.log('Network getfriendsscore not ok', res)
            if (callback) {
              callback(false);
            }
            return;
          }

          // console.log('Network requestFriendsScore success', res)

          callback(true, res.data);
        },
        fail: function fail(err) {
          // console.log('Network getfriendsscore fail', err)
          callback(false, false);
        }
      });
    }
  }, {
    key: 'requestSettlement',
    value: function requestSettlement() {
      var score = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
      var times = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
      var callback = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : function () {};
      var verifyData = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};

      if (!_session2.default.sessionId) {
        // console.log('Network requestSettlement abort for no sessionId')
        callback(false);
        return;
      }
      // var scoreInfo = [
      //   { type: 0, score: score },
      //   { type: 2, score: times }
      // ]
      var scoreInfo = {
        score: score,
        times: times,
        game_data: JSON.stringify(verifyData)
      };

      var obj = {
        base_req: {
          session_id: _session2.default.sessionId,
          fast: 1
        },
        // score_info: scoreInfo,
        action_data: (0, _encryption.encrypt)(scoreInfo, _session2.default.sessionId)
      };

      wx.request({
        url: networkConfig.AJAX_URL + '/wxagame/wxagame_settlement',
        method: 'POST',
        data: obj,
        success: function success(res) {
          if (res.statusCode !== 200) {
            // console.log('Network requestCreateGame not ok', res)
            callback(false);
            return;
          }
          if (res.data.base_resp.errcode === 0) {
            // console.log('Network request settlement success', res)
            callback(true);
          } else {
            // console.log('Network request settlement fail', res)
            callback(false);
          }
        },
        fail: function fail(res) {
          // console.log('Network request settlement fail', res)
          callback(false);
        }
      });
    }
  }, {
    key: 'requestCreateGame',
    value: function requestCreateGame() {
      var callback = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : function () {};

      if (_session2.default.serverConfig) {
        // 0是关，1是开  !0 true !1 false
        if (!_session2.default.serverConfig.audience_mode_switch) {
          // console.log('requestCreateGame server forbidden')
          callback(false, '当前围观人数过多，请稍后再试');
          return;
        }
      }

      if (!_session2.default.sessionId) {
        this.reGetSessionId('requestCreateGame', callback);
        // console.log('Network create game request sessionId')
      }

      var obj = {
        base_req: {
          session_id: _session2.default.sessionId,
          fast: 1
        }
      };

      wx.request({
        url: networkConfig.AJAX_URL + '/wxagame/wxagame_creategame',
        method: 'POST',
        data: obj,
        success: function success(res) {
          if (res.statusCode !== 200) {
            // console.log('Network requestCreateGame not ok', res)
            callback(false);
            return;
          }
          if (res.data.base_resp.errcode === 0) {
            // console.log('Network createGame success', res)
            callback(true, res);
          } else {
            // console.log('Network createGame fail', res)
            callback(false);
          }
        },
        fail: function fail(res) {
          // console.log('Network createGame fail', res)
          callback(false);
        }
      });

      // { 返回包示例
      //   data:{
      //     base_resp:{errcode},
      //     game_id:''
      //   }
      // }
    }
  }, {
    key: 'reGetSessionId',
    value: function reGetSessionId(name, cb) {
      var _this = this;

      // console.log('network reGetSessionId:', name)
      _storage2.default.clearSessionId();
      this.requestLogin(function (success) {
        if (success) {
          if (cb) {
            _this[name](cb);
          } else {
            _this[name]();
          }
        } else {
          if (cb) {
            cb(false);
          }
        }
      });
    }

    /**
    * 服务器发的配置存在内存和缓存里
    */

  }, {
    key: 'requestInit',
    value: function requestInit() {
      if (!_session2.default.sessionId) {
        // console.log('Network requestInit request sessionId')
        return;
        this.reGetSessionId('requestInit');
      }

      if (_session2.default.serverConfig) {
        var v = _session2.default.serverConfig.version;
        this.requestServerInit(v);
      } else {
        this.requestServerInit(0);
      }
    }
  }, {
    key: 'requestServerInit',
    value: function requestServerInit(version) {
      var obj = {
        base_req: {
          session_id: _session2.default.sessionId,
          fast: 1
        },
        version: version
      };

      wx.request({
        url: networkConfig.AJAX_URL + '/wxagame/wxagame_init',
        method: 'POST',
        data: obj,
        success: function success(res) {
          if (res.statusCode !== 200) {
            // console.log('Network requestInit not ok', res)
            return;
          }

          // 当sessionId过期的逻辑
          // if (res.data.base_resp.errcode === -5) {

          //   this.reGetSessionId('requestInit')
          //   return
          // }

          if (res.data.base_resp.errcode !== 0) {
            // console.log('Network requestInit not ok', res)
            return;
          }

          // console.log('Network requestInit success', res)
          if (res.data.version > _session2.default.serverConfig.version || !_session2.default.serverConfig.version) {
            _session2.default.setServerConfig(res.data);
            _storage2.default.saveServerConfig(res.data);
          }
        },
        fail: function fail(err) {
          // console.log('Network requestInit fail', err)
        }
      });
    }
  }, {
    key: 'getGroupScore',
    value: function getGroupScore() {
      var callback = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : function () {};

      if (!_session2.default.sessionId) {
        // console.log('Network getGroupScore not ok need sessionID')
        callback(false);
        return;
      }
      var obj = {
        base_req: {
          session_id: _session2.default.sessionId,
          fast: 1,
          group_info: {
            share_ticket: _session2.default.shareTicket
          }
        }
      };

      wx.request({
        url: networkConfig.AJAX_URL + '/wxagame/wxagame_getgrouprank',
        method: 'POST',
        data: obj,
        success: function success(res) {
          if (res.statusCode !== 200) {
            // console.log('Network getGroupScore not ok', res)
            callback(false);
            return;
          }

          // 当sessionId过期的逻辑
          // if (res.data.base_resp.errcode === -5) {

          //   this.reGetSessionId('getGroupScore', callback)
          //   return
          // }

          if (res.data.base_resp.errcode !== 0) {
            // console.log('Network getGroupScore not ok', res)
            callback(false);
            return;
          }
          // console.log('Network getGroupScore success', res)
          callback(true, res);
        },
        fail: function fail(err) {
          // console.log('Network getGroupScore fail', err)
          callback(false);
        }
      });
    }
  }, {
    key: 'createPK',
    value: function createPK(score) {
      return new Promise(function (resolve, reject) {
        if (!_session2.default.sessionId) {
          // console.log('Network getGroupScore not ok need sessionID')
          reject();
          return;
        }
        wx.showLoading();
        var obj = {
          base_req: {
            session_id: _session2.default.sessionId,
            fast: 1
          },
          score: score
        };

        wx.request({
          url: networkConfig.AJAX_URL + '/wxagame/wxagame_createpk',
          method: 'POST',
          data: obj,
          success: function success(res) {
            if (res.statusCode !== 200) {
              // console.log('Network getPKID not ok', res)
              reject();
              return;
            }

            // // 当sessionId过期的逻辑
            // if (res.data.base_resp.errcode === -5) {

            //   this.reGetSessionId('getGroupScore', callback)
            //   return
            // }

            if (res.data.base_resp.errcode !== 0) {
              // console.log('Network getPKID not ok', res)
              reject();
              return;
            }

            _session2.default.setPkId(res.data.pk_id);
            // console.log('Network getPKID success', res.data.pk_id, res)
            resolve();
          },
          fail: function fail(err) {
            // console.log('Network getPKID fail', err)
            reject();
          },
          complete: function complete() {
            wx.hideLoading();
          }
        });
      });
    }
  }, {
    key: 'getBattleData',
    value: function getBattleData() {
      var callback = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : function () {};
      var pkId = arguments[1];

      if (!_session2.default.sessionId || !pkId) {
        // console.log('Network getBattleData not ok need sessionID pkId')
        callback(false);
        return;
      }

      var obj = {
        base_req: {
          session_id: _session2.default.sessionId,
          fast: 1
        },
        pk_id: pkId
      };

      if (_session2.default.shareTicket) {
        obj.base_req.group_info = {
          share_ticket: _session2.default.shareTicket
        };
      }

      // console.log('getBattleDatagetBattleDatagetBattleData', obj)
      wx.request({
        url: networkConfig.AJAX_URL + '/wxagame/wxagame_getpkinfo',
        method: 'POST',
        data: obj,
        success: function success(res) {
          if (res.statusCode !== 200) {
            // console.log('Network getBattleData not ok', res)
            callback(false);
            return;
          }

          // 当sessionId过期的逻辑
          // if (res.data.base_resp.errcode === -5) {

          //   this.reGetSessionId('getGroupScore', callback)
          //   return
          // }

          if (res.data.base_resp.errcode !== 0) {
            // console.log('Network getBattleData not ok', res)
            callback(false);
            return;
          }

          // console.log('Network getBattleData success', res)
          callback(true, res);
        },
        fail: function fail(err) {
          // console.log('Network getBattleData fail', err)
          callback(false);
        }
      });
    }
  }, {
    key: 'updatepkinfo',
    value: function updatepkinfo() {
      var callback = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : function () {};
      var pkId = arguments[1];
      var score = arguments[2];

      if (!_session2.default.sessionId || !pkId) {
        // console.log('Network getBattleData not ok need sessionID pkId')
        callback(false);
        return;
      }

      var obj = {
        base_req: {
          session_id: _session2.default.sessionId,
          fast: 1
        },
        pk_id: pkId,
        score: score

        // console.log('updatepkinfoupdatepkinfoupdatepkinfo', obj)
      };wx.request({
        url: networkConfig.AJAX_URL + '/wxagame/wxagame_updatepkinfo',
        method: 'POST',
        data: obj,
        success: function success(res) {
          if (res.statusCode !== 200) {
            // console.log('Network updatepkinfo not ok', res)
            callback(false);
            return;
          }

          // // 当sessionId过期的逻辑
          // if (res.data.base_resp.errcode === -5) {

          //   this.reGetSessionId('getGroupScore', callback)
          //   return
          // }

          if (res.data.base_resp.errcode !== 0) {
            // console.log('Network updatepkinfo not ok', res)
            callback(false);
            return;
          }

          // console.log('Network updatepkinfo success', res)
          callback(true, res);
        },
        fail: function fail(err) {
          // console.log('Network updatepkinfo fail', err)
          callback(false);
        }
      });
    }
  }, {
    key: 'quitGame',
    value: function quitGame() {
      var callback = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : function () {};

      if (!_session2.default.gameId && !_session2.default.sessionId) {
        // console.log('Network quitGame not ok need sessionID gameId')
        callback(false);
        return;
      }

      var obj = {
        base_req: {
          session_id: _session2.default.sessionId,
          fast: 1
        },
        game_id: _session2.default.gameId
      };

      wx.request({
        url: networkConfig.AJAX_URL + '/wxagame/wxagame_quitgame',
        method: 'POST',
        data: obj,
        success: function success(res) {
          if (res.statusCode !== 200) {
            // console.log('Network updatepkinfo not ok', res)
            callback(false);
            return;
          }

          // 当sessionId过期的逻辑
          // if (res.data.base_resp.errcode === -5) {

          //   this.reGetSessionId('quitGame', callback)
          //   return
          // }

          if (res.data.base_resp.errcode !== 0) {
            // console.log('Network quitGame not ok', res)
            callback(false);
            return;
          }

          // console.log('Network quitGame success', res)
          callback(true, res);
        },
        fail: function fail(err) {
          // console.log('Network quitGame fail', err)
          callback(false);
        }
      });
    }
  }, {
    key: 'syncop',
    value: function syncop() {
      var cb = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : function () {};

      if (!_session2.default.gameId && !_session2.default.sessionId) {
        // console.log('Network quitGame not ok need sessionID gameId')
        callback(false);
        return;
      }
      var obj = {
        base_req: {
          session_id: _session2.default.sessionId,
          fast: 1
        },
        game_id: _session2.default.gameId
      };

      wx.request({
        url: networkConfig.AJAX_URL + '/wxagame/wxagame_syncop',
        method: 'POST',
        data: obj,
        success: function success(res) {
          if (res.statusCode !== 200) {
            // console.log('Network syncop not ok', res)
            cb(false);
            return;
          }

          if (res.data.base_resp.errcode !== 0) {
            // console.log('Network syncop not ok', res)
            cb(false);
            return;
          }

          // console.log('Network syncop success', res)
          cb(true, res);
        },
        fail: function fail(err) {
          cb(false);
          // console.log('Network syncop fail', err)
        }
      });
    }
  }, {
    key: 'sendReport',
    value: function sendReport() {
      var reportList = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
      var clientInfo = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      if (!_session2.default.sessionId) {
        // console.log('sendReport need session ID')
        return;
      }

      var obj = {
        base_req: {
          session_id: _session2.default.sessionId,
          fast: 1,
          client_info: clientInfo
        },
        report_list: reportList
      };
      wx.request({
        url: networkConfig.AJAX_URL + '/wxagame/wxagame_bottlereport',
        method: 'POST',
        data: obj,
        success: function success(res) {
          // console.log('Network sendReport success', res)
        },
        fail: function fail() {
          // console.log('Network sendReport fail')
        }
      });
    }
  }, {
    key: 'badReport',
    value: function badReport(msg, stack) {
      var res = wx.getSystemInfoSync();
      var sessionId = _session2.default.sessionId || '';
      var msg = 'model:' + res.model + ',SDKVersion:' + res.SDKVersion + ',version:' + res.version + ',sessionId:' + sessionId + ',errmsg:' + msg + ',stack:' + stack;
      wx.request({
        url: 'https://badjs.weixinbridge.com/badjs',
        data: {
          id: 130,
          level: 4,
          msg: msg
        },
        success: function success(res) {
          // console.log('Network badjs', res)
        },
        fail: function fail(res) {
          // console.log('Network badjs', res)
        }
      });
    }
  }, {
    key: 'sendServerError',
    value: function sendServerError(key) {
      if (!_session2.default.sessionId) {
        // console.log('sendReport need session ID')
        return;
      }

      var obj = {
        base_req: {
          session_id: _session2.default.sessionId,
          fast: 1
        },
        id: 1,
        key: key
      };

      wx.request({
        url: networkConfig.AJAX_URL + '/wxagame/wxagame_jsreport',
        method: 'POST',
        data: obj,
        success: function success(res) {
          // console.log('Network sendServerError success', res)
        },
        fail: function fail() {
          // console.log('Network sendServerError fail')
        }
      });
    }
  }]);

  return Network;
}();

exports.default = Network;

/***/ }),