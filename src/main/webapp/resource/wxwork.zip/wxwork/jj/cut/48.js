
/* 48 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var WaitingPage = function () {
  function WaitingPage(game) {
    _classCallCheck(this, WaitingPage);

    this.game = game;
    this.model = this.game.gameModel;
    this.full2D = this.game.full2D;
    this.UI = this.game.UI;
    this.name = 'viewerWaiting';
  }

  _createClass(WaitingPage, [{
    key: 'show',
    value: function show() {
      var observeInfo = this.model.observeInfo;
      this.full2D.showLookersPage({
        type: 'in',
        headimg: observeInfo.headimg,
        nickname: observeInfo.nickName
      });
      this.UI.scoreText.obj.position.x = 0;
      this.UI.scoreText.obj.position.y = 11;
      this.UI.scoreText.changeStyle({ textAlign: 'center' });
      this.UI.showScore();
    }
  }, {
    key: 'hide',
    value: function hide() {
      this.full2D.hide2D();
      this.UI.hideScore();
      this.UI.scoreText.obj.position.y = 21;
      this.UI.scoreText.obj.position.x = -13;
      this.UI.scoreText.changeStyle({ textAlign: 'left' });
    }
  }]);

  return WaitingPage;
}();

exports.default = WaitingPage;

/***/ }),