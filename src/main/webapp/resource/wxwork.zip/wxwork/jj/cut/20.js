
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _session = __webpack_require__(6);

var _session2 = _interopRequireDefault(_session);

var _network = __webpack_require__(3);

var _network2 = _interopRequireDefault(_network);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var GameSocket = function () {
  function GameSocket(game) {
    var _this = this;

    _classCallCheck(this, GameSocket);

    this.alive = false;
    this.noErr = false;
    // this.joinGame = false
    this.game = game;

    this.handlers = {};
    this.handleSocketErr = '';
    // 用来清除心跳，防止发送过多心跳
    this.heartBeat = [];

    /**
     * 命令池,数据格式
     * cmdPool = {
     *  'gameId': {
     *    n:当前帧序号
     *    arr:[]序号指令池
     *  }
     * }
     */
    this.cmdPool = {};

    wx.onSocketOpen(function (res) {
      // console.log('Socket open', res)
      _this.joinGame();
    });

    wx.onSocketClose(function (res) {
      if (_this.game.mode == 'player' && !_this.noErr) {
        _network2.default.quitGame();
        _this.game.gameCtrl.onSocketCloseErr();
      }
      if (_this.game.mode == 'observe' && !_this.noErr) {
        _this.game.gameCtrl.onSocketCloseErr();
      }
      _this.alive = false;
      // console.log('Socket close', res)
    });

    wx.onSocketError(function (res) {
      // console.log('Socket connect fail', res)

      // 错误处理
      // if (typeof this.handleSocketErr == 'function') {
      //   this.handleSocketErr()
      // }
    });

    wx.onSocketMessage(function (res) {
      // console.log('Socket receive message1', res)
      // wx.hideLoading()

      // 清空心跳队列
      _this.cleanHeartBeat();

      var data;
      try {
        data = JSON.parse(res.data);
      } catch (error) {
        // console.log('onSocketMessage err: ', error, 'socket will be close')
        _this.game.handleWxOnError({
          message: 'socket receive wrong msg JSON.parse(res.data) error',
          stack: ''
        });
        wx.closeSocket();
        return;
      }

      // 发送帧的确认帧
      if (data.cmd === 106) {
        _this.handleACK(data);
      }

      // 加入游戏响应 
      if (data.cmd === 101) {
        _this.handleJoinGame(data);
      }

      if (data.cmd === 104) {
        // console.log('receive heart beat')
      }

      if (data.cmd === 108) {
        _this.handlePeopleCome(data);
      }

      if (data.cmd === 102) {
        _this.receiveCommand(data);
      }

      // 围观模式下
      if (data.cmd == 109) {
        _this.close();
      }

      // 主播退出直播了
      if (data.cmd == 107) {
        _this.handlePlayerOut();
      }

      _this.heartBeat.push(setTimeout(_this.sendHeartBeat.bind(_this), 5000));
      // this.heartBeat.push(setTimeout(this.sendHeartBeat.bind(this), 1000))
    });
  }

  _createClass(GameSocket, [{
    key: 'cleanHeartBeat',
    value: function cleanHeartBeat() {
      if (this.heartBeat.length) {
        while (this.heartBeat.length) {
          var heartBeat = this.heartBeat.pop();
          clearTimeout(heartBeat);
        }
      }
    }
  }, {
    key: 'handleSocketOpen',
    value: function handleSocketOpen() {
      this.joinGame();
      this.alive = true;
    }
  }, {
    key: 'connectSocket',
    value: function connectSocket() {
      var _this2 = this;

      this.alive = true;
      wx.connectSocket({
        // url: 'ws://mptest.weixin.qq.com/game/',
        url: 'wss://wxagame.weixin.qq.com',
        fail: function fail() {
          _this2.alive = false;
          // this.handleConnectSocketFail()
        }
      });
    }

    // handleConnectSocketFail() {
    //   this.alive = false
    //   if (this.game.mode == 'player') {
    //     this.game.shareObservCardFail()
    //   }
    //   if (this.game.mode == 'observe') {
    //     this.handleSocketErr(true)
    //   }
    // }

  }, {
    key: 'addHandler',
    value: function addHandler(cmd, cb) {
      if (!this.handlers[cmd]) {
        this.handlers[cmd] = [cb];
      } else {
        this.handlers[cmd].push(cb);
      }
    }

    // 发送指令

  }, {
    key: 'sendCommand',
    value: function sendCommand(cmdSequence, data) {
      var gameId = _session2.default.gameId;
      var gameTicket = _session2.default.gameTicket;
      if (!gameId || !gameTicket || !cmdSequence) {
        return;
      }
      if (typeof gameId !== 'string') {
        console.warn('Socket send cmd need gameId');
        return;
      }

      var obj = {
        cmd: 102,
        i: gameId,
        n: cmdSequence,
        k: gameTicket,
        o: [JSON.stringify(data)]
        // const obj = {
        //   cmd: 102,
        //   i: gameId,
        //   k: gameTicket,
        //   o: []
        // }
        // console.log('send Message', JSON.stringify(obj))
      };wx.sendSocketMessage({
        data: JSON.stringify(obj)
      });
    }
  }, {
    key: 'sendNullCommand',
    value: function sendNullCommand() {
      var gameId = _session2.default.gameId;
      var gameTicket = _session2.default.gameTicket;
      if (!gameId || !gameTicket) {
        return;
      }
      if (typeof gameId !== 'string') {
        console.warn('Socket send cmd need gameId');
        return;
      }

      var obj = {
        cmd: 102,
        i: gameId,
        k: gameTicket,
        o: []
        // console.log('send heartBeat Message', JSON.stringify(obj))
      };wx.sendSocketMessage({
        data: JSON.stringify(obj)
      });
    }
  }, {
    key: 'getCommand',
    value: function getCommand(gameId) {}
  }, {
    key: 'onPeopleCome',
    value: function onPeopleCome(cb) {
      this.peopleCome = cb;
    }
  }, {
    key: 'onReciveCommand',
    value: function onReciveCommand(cb) {
      this.observerMessage = cb;
    }
  }, {
    key: 'onJoinSuccess',
    value: function onJoinSuccess(cb) {
      this.joinSuccess = cb;
    }
  }, {
    key: 'onPlayerOut',
    value: function onPlayerOut(cb) {
      this.playerOutHandler = cb;
    }

    // 接收到指令

  }, {
    key: 'receiveCommand',
    value: function receiveCommand(res) {
      // console.log('receiveCommand',res)
      if (typeof this.observerMessage !== 'function') {
        return;
      }
      if (!res.o) {
        return;
      }
      if (!res.o[0]) {
        return;
      }
      if (!res.o[0].o) {
        return;
      }
      this.observerMessage(res.n, JSON.parse(res.o[0].o));
      return;
    }
  }, {
    key: 'handlePeopleCome',
    value: function handlePeopleCome(res) {
      if (typeof this.peopleCome !== 'function') {
        return;
      }
      this.peopleCome(res);
      return;
    }

    // 接收到指令确认帧

  }, {
    key: 'receiveACK',
    value: function receiveACK() {}

    // 加入游戏
    /**
     *  observe : handleConnectSocketfail => handleSocketFucked
     */

  }, {
    key: 'joinGame',
    value: function joinGame() {
      // console.log('Socket open success')
      var gameId = _session2.default.gameId;
      if (!_session2.default.sessionId || !gameId) {
        // console.log('Socket join game fail')
        // this.handleConnectSocketFail()
        return;
      }
      var obj = {
        cmd: 101,
        game_id: gameId,
        fast: 1,
        session_id: _session2.default.sessionId
      };

      wx.sendSocketMessage({
        data: JSON.stringify(obj)
      });
      // console.log('Socket join game', obj)
    }
  }, {
    key: 'handleACK',
    value: function handleACK(data) {
      if (this.handlers['ack']) {
        this.handlers['ack'].forEach(function (cb) {
          cb(data);
        });
      }
    }
  }, {
    key: 'handleJoinGame',
    value: function handleJoinGame(data) {
      // console.log(data)
      if (this.game.mode == 'observe') {
        switch (data.ret) {
          // 成功
          case 0:
            this.joinSuccess(true);
            break;
          // 不活跃
          case 2:
            this.joinSuccess(true);
            break;
          default:
            this.joinSuccess(false);
            break;
        }
      } else {
        if (data.ret != 0) {
          this.joinSuccess(false);
        } else {
          this.joinSuccess(true);
        }
      }

      // if (this.game.mode == 'player') {
      //   if (data.ret != 0) {
      //     this.close()
      //     this.handleConnectSocketFail()
      //   } else {
      //     this.joinSuccess()
      //   }
      // }
    }
  }, {
    key: 'sendHeartBeat',
    value: function sendHeartBeat() {
      if (this.game.mode == 'player') {
        this.sendNullCommand();
      } else {

        var obj = {
          cmd: 104
        };
        wx.sendSocketMessage({
          data: JSON.stringify(obj)
        });
      }
    }

    // reset() {
    //   this.handlers = {}
    //   this.heartBeat = []
    //   this.cmdPool = {}
    // }

  }, {
    key: 'quitObserve',
    value: function quitObserve() {
      if (!this.alive) {
        return;
      }
      // console.log('quitObservequitObserve')
      var obj = {
        cmd: 109,
        fast: 1,
        game_id: _session2.default.gameId,
        session_id: _session2.default.sessionId
        // console.log(obj)
      };wx.sendSocketMessage({
        data: JSON.stringify(obj)
      });
    }
  }, {
    key: 'close',
    value: function close() {
      var _this3 = this;

      if (!this.alive) {
        return;
      }

      this.alive = false;
      this.noErr = true;
      // console.log('emmit close')
      wx.closeSocket();

      _session2.default.clearShareTicket();
      _session2.default.clearGameId();

      setTimeout(function () {
        _this3.reset();
      }, 1000);
    }
  }, {
    key: 'onSocketErr',
    value: function onSocketErr(cb) {
      this.handleSocketErr = cb;
    }
  }, {
    key: 'reset',
    value: function reset() {
      this.alive = false;
      this.noErr = false;
    }
  }, {
    key: 'handlePlayerOut',
    value: function handlePlayerOut() {
      if (typeof this.playerOutHandler == 'function') {
        this.playerOutHandler();
      }
    }
  }]);

  return GameSocket;
}();

exports.default = GameSocket;

/***/ }),