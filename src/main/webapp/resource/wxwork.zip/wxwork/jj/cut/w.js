
/* 22 */
/***/function (module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	var location = {
		href: 'game.js',
		reload: function reload() {}
	};

	exports.default = location;

	/***/
}]
/******/);

/***/ }),