
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _three = __webpack_require__(1);

var THREE = _interopRequireWildcard(_three);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var singleSettlementPage = function () {
  function singleSettlementPage(camera) {
    _classCallCheck(this, singleSettlementPage);

    var material = new THREE.MeshBasicMaterial({ color: 0x0080c0 });
    var rankList = new THREE.Mesh(new THREE.PlaneGeometry(5, 5), material);
    var replay = rankList.clone();
    var challenge = rankList.clone();

    replay.position.set(0, -20, -1);
    rankList.position.set(-10, -20, -1);
    challenge.position.set(10, -20, -1);

    this.ui = [replay, rankList, challenge];
    this.camera = camera;
  }

  _createClass(singleSettlementPage, [{
    key: 'show',
    value: function show() {
      var _this = this;

      this.ui.forEach(function (ui) {
        _this.camera.add(ui);
      });
    }
  }, {
    key: 'hide',
    value: function hide() {
      var _this2 = this;

      this.ui.forEach(function (ui) {
        _this2.camera.remove(ui);
      });
    }
  }]);

  return singleSettlementPage;
}();

exports.default = singleSettlementPage;

/***/ }),