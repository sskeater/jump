
/* 47 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var outPage = function () {
  function outPage(game) {
    _classCallCheck(this, outPage);

    this.game = game;
    this.model = this.game.gameModel;
    this.full2D = this.game.full2D;
    this.UI = this.game.UI;
    this.name = 'viewerOut';
  }

  _createClass(outPage, [{
    key: 'show',
    value: function show() {
      var observeInfo = this.model.observeInfo;
      this.full2D.showLookersPage({
        type: 'out',
        headimg: observeInfo.headimg,
        nickname: observeInfo.nickName
      });
      this.UI.hideScore();
    }
  }, {
    key: 'hide',
    value: function hide() {
      this.full2D.hide2D();
    }
  }]);

  return outPage;
}();

exports.default = outPage;

/***/ }),