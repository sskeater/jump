
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var GameView = function () {
  function GameView(game) {
    _classCallCheck(this, GameView);

    this.game = game;
  }

  _createClass(GameView, [{
    key: 'init',
    value: function init() {}
  }, {
    key: 'showIdentifyModeErr',
    value: function showIdentifyModeErr(wording) {
      this.showModal(wording);
    }
  }, {
    key: 'showNoSession',
    value: function showNoSession() {
      this.showModal();
    }
  }, {
    key: 'showGetPkIdFail',
    value: function showGetPkIdFail() {
      this.showModal();
    }
  }, {
    key: 'showGroupShareFail',
    value: function showGroupShareFail() {
      var wording = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '网络异常,点击确定回到游戏';

      this.showModal(wording);
    }
  }, {
    key: 'showGoToBattleFail',
    value: function showGoToBattleFail() {
      this.showModal();
    }
  }, {
    key: 'showUploadPkScoreFail',
    value: function showUploadPkScoreFail() {
      this.showModal('数据上传失败');
    }
  }, {
    key: 'showShareObserveCardFail',
    value: function showShareObserveCardFail(res) {
      this.showModal(res);
    }
  }, {
    key: 'showObserveStateFail',
    value: function showObserveStateFail() {
      this.showModal('服务器异常');
    }
  }, {
    key: 'showModal',
    value: function showModal() {
      var wording = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '网络异常,点击确定回到游戏';

      wx.showModal({
        title: '提示',
        content: wording,
        showCancel: false
      });
    }
  }, {
    key: 'showServeConfigForbiddenObserveMode',
    value: function showServeConfigForbiddenObserveMode() {
      this.showModal('当前围观人数过多，请稍后再试');
    }
  }, {
    key: 'showServeConfigForbiddenGroupShare',
    value: function showServeConfigForbiddenGroupShare() {
      this.showModal('查看群排行人数过多，请稍后再试');
    }
  }, {
    key: 'showSocketCloseErr',
    value: function showSocketCloseErr() {
      // this.showModal('网络连接异常，点击确定回到游戏')
    }
  }, {
    key: 'showSyncopErr',
    value: function showSyncopErr() {
      return;
    }
  }]);

  return GameView;
}();

exports.default = GameView;

/***/ }),