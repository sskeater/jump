
/* 32 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _battlePkPage = __webpack_require__(43);

var _battlePkPage2 = _interopRequireDefault(_battlePkPage);

var _battleGamePage = __webpack_require__(42);

var _battleGamePage2 = _interopRequireDefault(_battleGamePage);

var _network = __webpack_require__(3);

var _network2 = _interopRequireDefault(_network);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var BattleCtrl = function () {
  function BattleCtrl(game, modeCtrl) {
    _classCallCheck(this, BattleCtrl);

    this.name = 'battlePage';
    this.game = game;
    this.gameCtrl = this.game.gameCtrl;
    this.model = this.game.gameModel;
    this.view = this.game.gameView;
    this.modeCtrl = modeCtrl;
    this.netWorkCtrl = this.gameCtrl.netWorkCtrl;
    this.currentPage = null;
    this.pkPage = new _battlePkPage2.default(game);
    this.gamePage = new _battleGamePage2.default(game);

    this.shareTicket = '';
    this.pkId = '';
    this.shareInfoTimeout = null;
    this.battleScore = undefined;
  }

  _createClass(BattleCtrl, [{
    key: 'init',
    value: function init(options) {
      var sessionId = this.model.getSessionId();
      this.shareTicket = options.shareTicket;
      this.pkId = options.query.pkId;
      this.model.setStage('');
      wx.showLoading();
      if (!sessionId) {
        this.netWorkCtrl.netWorkLogin(this.afterLogin.bind(this));
      } else {
        this.afterLogin(true);
      }
    }
  }, {
    key: 'afterLogin',
    value: function afterLogin(success) {
      var _this = this;

      if (success) {
        this.setShareInfoTimeout();

        // 换取rawdata
        wx.getShareInfo({
          shareTicket: this.shareTicket,
          success: function success(res) {

            // 如果定时器还没有触发，就取消定时器
            if (_this.shareInfoTimeout != null) {
              // console.log('没有触发定时器')
              _this.clearShareInfoTimeout();
            } else {
              // console.log('已经触发定时器')
              return;
            }
            _this.model.setShareTicket(res.rawData);

            // console.log('wx.getShareInfo success group', res)
            _this.gotoBattlePage();
            _this.gameCtrl.loginBattle(1);
          },
          fail: function fail(res) {

            // 如果定时器还没有触发，就取消定时器
            if (_this.shareInfoTimeout != null) {
              _this.clearShareInfoTimeout();
              // console.log('没有触发定时器')
            } else {
              // console.log('已经触发定时器')
              return;
            }

            // 失败就是个人
            _this.gotoBattlePage();
            _this.gameCtrl.loginBattle(0);
          }
        });
      } else {
        this.goToBattleFail();
      }
    }
  }, {
    key: 'gotoBattlePage',
    value: function gotoBattlePage() {

      // 拉分数
      _network2.default.getBattleData(this.gotoBattlePageAfterHaveData.bind(this), this.pkId);
    }
  }, {
    key: 'gotoBattlePageAfterHaveData',
    value: function gotoBattlePageAfterHaveData(success, res) {
      wx.hideLoading();
      if (success) {
        var pkList = [];
        if (res.data.challenger.length) {
          res.data.challenger.forEach(function (el) {
            pkList.push({
              headimg: el.headimg,
              is_self: el.is_self ? 1 : 0,
              nickname: el.nickname,
              score_info: [{
                score: el.score
              }]
            });
          }, this);
        }

        pkList.sort(function (a, b) {
          return b.score_info[0].score - a.score_info[0].score;
        });

        var obj = {
          data: {
            organizerInfo: {
              headimg: res.data.owner.headimg,
              nickname: res.data.owner.nickname,
              score_info: [{
                score: res.data.owner.score
              }],
              // create_time: res.data.create_time,
              left_time: res.data.left_time,
              is_self: res.data.is_owner ? 1 : 0
            },
            pkListInfo: pkList,
            gg_score: this.battleScore
          }
        };

        if (this.currentPage) {
          this.currentPage.hide();
        }
        this.pkPage.show(obj);
        this.model.setStage(this.pkPage.name);
        this.currentPage = this.pkPage;

        this.gameCtrl.showPkPage(res.data.owner.score);
      } else {
        this.goToBattleFail();
      }
    }
  }, {
    key: 'goToBattleFail',
    value: function goToBattleFail() {
      this.view.showGoToBattleFail();
      this.modeCtrl.changeMode('singleCtrl');
    }
  }, {
    key: 'setShareInfoTimeout',
    value: function setShareInfoTimeout() {
      this.shareInfoTimeout = setTimeout(this.handleShareInfoTimeout.bind(this), 5000);
    }
  }, {
    key: 'clearShareInfoTimeout',
    value: function clearShareInfoTimeout() {
      if (this.shareInfoTimeout != null) {
        clearTimeout(this.shareInfoTimeout);
        this.shareInfoTimeout = null;
      }
    }
  }, {
    key: 'handleShareInfoTimeout',
    value: function handleShareInfoTimeout() {
      this.clearShareInfoTimeout();
      this.goToBattleFail();
    }
  }, {
    key: 'destroy',
    value: function destroy() {
      if (this.currentPage) {
        this.currentPage.hide();
      }
      this.model.setStage('');
      wx.hideLoading();
      this.shareTicket = '';
      this.pkId = '';
      this.clearShareInfoTimeout();
      this.model.clearShareTicket();
      this.game.resetScene();
      this.battleScore = undefined;
    }
  }, {
    key: 'battlePlay',
    value: function battlePlay(pk) {
      if (pk) {
        if (this.currentPage) {
          this.currentPage.hide();
        }
        this.gamePage.show();
        this.game.replayGame();
        this.model.setStage(this.gamePage.name);
        this.currentPage = this.gamePage;
      } else {
        this.modeCtrl.directPlaySingleGame();
        this.gameCtrl.battleToSingle();
      }
    }
  }, {
    key: 'showGameOverPage',
    value: function showGameOverPage() {
      if (this.currentPage) {
        this.currentPage.hide();
      }
      this.model.setStage('');
      this.currentPage = null;
      var score = this.model.currentScore;
      this.battleScore = score;

      // 先上传分数，然后再拉分数
      wx.showLoading();
      _network2.default.updatepkinfo(this.gotoBattlePageAgain.bind(this), this.pkId, score);
    }
  }, {
    key: 'gotoBattlePageAgain',
    value: function gotoBattlePageAgain(scoreUpLoad) {
      if (!scoreUpLoad) {
        this.view.showUploadPkScoreFail();
      }

      this.gotoBattlePage();
    }
  }, {
    key: 'wxOnhide',
    value: function wxOnhide() {
      return;
    }
  }]);

  return BattleCtrl;
}();

exports.default = BattleCtrl;

/***/ }),