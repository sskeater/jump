
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _storage = __webpack_require__(5);

var _storage2 = _interopRequireDefault(_storage);

var _network = __webpack_require__(3);

var _network2 = _interopRequireDefault(_network);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

// var data = {
//   accurate: 0,
//   bonus: 0
// }

var historyTimes = function () {
  function historyTimes(game) {
    _classCallCheck(this, historyTimes);

    this.times = _storage2.default.getHistoryTimes();
    if (!this.times) {
      this.times = {
        accurate: 0,
        bonus: 0
      };
    }
    this.game = game;
    this.limitScore = 5;
  }

  // 与服务器的数据进行比较


  _createClass(historyTimes, [{
    key: 'verifyScore',
    value: function verifyScore(onlineScore) {
      if (onlineScore >= this.times.accurate) {

        // 如果网上的分数比当前分数大，则赋值，更新本地缓存
        this.times.accurate = onlineScore;

        if (this.times.bonus >= this.limitScore) {

          // 如果累加分数超过5分
          this.upLoadHistoryTimes();
        } else {

          _storage2.default.saveHistoryTimes(this.times);
        }
      } else {
        this.upLoadHistoryTimes();
      }
    }
  }, {
    key: 'addOne',
    value: function addOne() {
      // console.log('score add one')
      this.times.bonus++;
      // this.checkUp()
    }
  }, {
    key: 'checkUp',
    value: function checkUp() {
      if (this.times.bonus >= this.limitScore) {

        // 如果累加分数超过5分
        this.upLoadHistoryTimes();
      } else {
        _storage2.default.saveHistoryTimes(this.times);
      }
    }
  }, {
    key: 'upLoadHistoryTimes',
    value: function upLoadHistoryTimes() {
      var highestScore = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
      var verifyData = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      var times = this.times.accurate + this.times.bonus;
      // 上传分数
      _network2.default.requestSettlement(highestScore, times, this.afterUpload.bind(this), verifyData);
    }
  }, {
    key: 'afterUpload',
    value: function afterUpload(success) {
      if (success) {
        this.times.accurate += this.times.bonus;
        this.times.bonus = 0;
      }
      _storage2.default.saveHistoryTimes(this.times);
    }
  }, {
    key: 'getTimes',
    value: function getTimes() {
      return this.times.accurate + this.times.bonus;
    }
  }]);

  return historyTimes;
}();

exports.default = historyTimes;

/***/ }),