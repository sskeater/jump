
/* 37 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _singleCtrl = __webpack_require__(10);

var _singleCtrl2 = _interopRequireDefault(_singleCtrl);

var _shareApp = __webpack_require__(7);

var _playerGamePage = __webpack_require__(49);

var _playerGamePage2 = _interopRequireDefault(_playerGamePage);

var _network = __webpack_require__(3);

var _network2 = _interopRequireDefault(_network);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var playerCtrl = function (_SingleCtrl) {
  _inherits(playerCtrl, _SingleCtrl);

  function playerCtrl(game, modeCtrl) {
    _classCallCheck(this, playerCtrl);

    var _this = _possibleConstructorReturn(this, (playerCtrl.__proto__ || Object.getPrototypeOf(playerCtrl)).call(this, game, modeCtrl));

    _this.name = 'player';
    _this.currentPage = null;
    _this.gamePage = new _playerGamePage2.default(game);
    return _this;
  }

  _createClass(playerCtrl, [{
    key: 'init',
    value: function init() {
      // this.model.setStage(this.gamePage.name)
      // this.gamePage.show()
      var stage = this.model.stage;
      switch (stage) {
        case 'game':
          this.currentPage = this.gamePage;
          this.currentPage.show();
          break;
        case 'singleSettlementPgae':
          this.currentPage = this.gameOverPage;
          break;
        default:
          this.model.setStage(this.gamePage.name);
          this.currentPage = this.gamePage;
          this.currentPage.show();
          break;
      }
    }
  }, {
    key: 'showGameOverPage',
    value: function showGameOverPage() {
      this.game.seq++;
      this.gameSocket.sendCommand(this.game.seq, {
        type: -1,
        s: this.game.currentScore
      });
      _get(playerCtrl.prototype.__proto__ || Object.getPrototypeOf(playerCtrl.prototype), 'showGameOverPage', this).call(this);
    }
  }, {
    key: 'shareObservCard',
    value: function shareObservCard() {
      this.shareObservCardA();
    }
  }, {
    key: 'shareObservCardA',
    value: function shareObservCardA() {
      this.shareObservCardB();
    }
  }, {
    key: 'shareObservCardB',
    value: function shareObservCardB() {
      var _this2 = this;

      this.model.setStage('loading');
      (0, _shareApp.shareObserve)(function (success, num) {
        if (!!success) {
          _this2.gameCtrl.afterShareObserveCard(num);
        }
        setTimeout(function () {
          // console.log('!!!!!!shareObservCardB,stage2', this.model.stage)
          if (_this2.model.stage == 'loading') {
            _this2.model.setStage('game');
          }
        }, 50);
      });
    }
  }, {
    key: 'gameOverClickReplay',
    value: function gameOverClickReplay() {
      _get(playerCtrl.prototype.__proto__ || Object.getPrototypeOf(playerCtrl.prototype), 'gameOverClickReplay', this).call(this);
      this.game.seq++;
      this.gameSocket.sendCommand(this.game.seq, {
        type: 0,
        seed: this.game.randomSeed
      });
    }
  }, {
    key: 'destroy',
    value: function destroy() {
      if (this.currentPage) {
        this.currentPage.hide();
      }
      this.currentPage = null;
      this.model.setStage('');
      if (this.gameSocket.alive) {
        // 关闭socket
        this.gameSocket.close();
      }

      // 清理gameId，gameTicket
      this.model.clearGameId();
      this.model.clearGameTicket();
      this.game.viewer.reset();
      // this.game.viewer.hideAll()

      this.game.resetScene();
    }
  }, {
    key: 'wxOnhide',
    value: function wxOnhide() {
      var _this3 = this;

      // 这个地方影响PK分享，群分享
      if (this.model.stage != 'loading' && this.model.stage != 'singleSettlementPgae' && this.model.stage != 'friendRankList') {

        _network2.default.quitGame();

        // 结束心跳
        this.gameSocket.cleanHeartBeat();

        this.gameSocket.close();
        setTimeout(function () {
          // this.handleNetworkFucked(true, '直播断开')
          // this.handleNetworkFucked()
          _this3.modeCtrl.changeMode('singleCtrl');
        }, 100);
      }
    }
  }, {
    key: 'wxOnshow',
    value: function wxOnshow() {}
  }]);

  return playerCtrl;
}(_singleCtrl2.default);

exports.default = playerCtrl;

/***/ }),