
/* 53 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var GamePage = function () {
  function GamePage(game) {
    _classCallCheck(this, GamePage);

    this.game = game;
    this.model = this.game.gameModel;
    this.full2D = this.game.full2D;
    this.UI = this.game.UI;
    this.viewer = this.game.viewer;
    this.name = 'game';
  }

  _createClass(GamePage, [{
    key: 'show',
    value: function show() {
      var is_from_wn = this.model.is_from_wn;
      var firstBlood = this.model.firstBlood;

      if (!is_from_wn && !this.game.guider) {
        // this.UI.observe.visible = true
        if (firstBlood) {
          this.viewer.lookers.showLookers({
            avaImg: false,
            icon: true,
            wording: true
          });
        } else {
          this.viewer.open();
        }
      }

      this.UI.showScore();

      this.UI.scoreText.obj.position.y = 21;
      this.UI.scoreText.obj.position.x = -13;
      this.UI.scoreText.changeStyle({ textAlign: 'left' });
    }
  }, {
    key: 'hide',
    value: function hide() {
      this.viewer.close();
      // this.UI.observe.visible = false
      this.UI.hideScore();
    }
  }, {
    key: 'hideLookersShare',
    value: function hideLookersShare() {
      var firstBlood = this.model.firstBlood;
      if (firstBlood) {
        this.model.setFirstBlood(false);
        this.viewer.open();
      }
    }
  }]);

  return GamePage;
}();

exports.default = GamePage;

/***/ }),