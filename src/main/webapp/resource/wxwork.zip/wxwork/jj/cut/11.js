
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _scroll = __webpack_require__(57);

var _scroll2 = _interopRequireDefault(_scroll);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var UNDERSCROLL_TRACKING = 0.5;

var ScrollHandler = function () {
  function ScrollHandler(options) {
    _classCallCheck(this, ScrollHandler);

    options = options || {};

    // this._element = element; // element 是内部的列表
    this._options = options;

    this._itemSize = options.itemSize || 0;

    this._innerOffsetHeight = options.innerOffsetHeight || 0; // 内部列表高度
    this._outterOffsetHeight = options.outterOffsetHeight || 0; // 外部容器高度

    this._extent = this._innerOffsetHeight - this._outterOffsetHeight; // 可滚动的高度

    this._position = 0;
    this._scroll = new _scroll2.default(this._extent);
    this.updatePosition();
  }

  _createClass(ScrollHandler, [{
    key: 'onTouchStart',
    value: function onTouchStart() {
      this._startPosition = this._position;
      this._lastChangePos = this._startPosition;

      // Ensure that we don't jump discontinuously when applying the underscroll
      // tracking in onTouchMove if the view is currently outside of the valid
      // scroll constraints.
      if (this._startPosition > 0) this._startPosition /= UNDERSCROLL_TRACKING;else if (this._startPosition < -this._extent) this._startPosition = (this._startPosition + this._extent) / UNDERSCROLL_TRACKING - this._extent;

      if (this._animation) {
        this._animation.cancel();
        this._scrolling = false;
      }
      this.updatePosition();
    }
  }, {
    key: 'onTouchMove',
    value: function onTouchMove(dx, dy) {
      // 
      var pos = this._startPosition;
      pos += dy;
      if (pos > 0) pos *= UNDERSCROLL_TRACKING;else if (pos < -this._extent) pos = (pos + this._extent) * UNDERSCROLL_TRACKING - this._extent;
      this._position = pos;

      this.updatePosition();
    }
  }, {
    key: 'onTouchEnd',
    value: function onTouchEnd(dx, dy, velocity) {
      var that = this;

      this._scroll.set(this._position, velocity.y);

      this._scrolling = true;
      this._lastChangePos = this._position;

      this._animation = this.animation(this._scroll, function () {
        var now = Date.now();
        var t = (now - that._scroll._startTime) / 1000.0;
        var pos = that._scroll.x(t);
        // console.log('t: ', t, ' pos: ', pos);
        that._position = pos;
        // The translateZ is to help older WebKits not collapse this layer into a non-composited layer
        // since they're also slow at repaints.
        that.updatePosition();
      }, function done() {
        that._scrolling = false;
      });
    }
  }, {
    key: 'scrollTo',
    value: function scrollTo(pos) {
      if (this._animation) {
        this._animation.cancel();
        this._scrolling = false;
      }

      if (typeof pos === 'number') {
        this._position = -pos;
      }

      if (this._position < -this._extent) {
        this._position = -this._extent;
      } else if (this._position > 0) {
        this._position = 0;
      }
      this.updatePosition();
    }
  }, {
    key: 'updatePosition',
    value: function updatePosition() {
      this._options.updatePosition(this._position);
    }
  }, {
    key: 'animation',
    value: function animation(physicsModel, callback, doneFn) {

      function onFrame(handle, model, cb, doneFn) {
        if (handle && handle.cancelled) return;
        cb(model);
        var done = physicsModel.done();
        if (!done && !handle.cancelled) {
          handle.id = requestAnimationFrame(onFrame.bind(null, handle, model, cb, doneFn));
        }
        if (done && doneFn) {
          doneFn(model);
        }
      }
      function cancel(handle) {
        if (handle && handle.id) cancelAnimationFrame(handle.id);
        if (handle) handle.cancelled = true;
      }

      var handle = { id: 0, cancelled: false };
      onFrame(handle, physicsModel, callback, doneFn);

      return { cancel: cancel.bind(null, handle), model: physicsModel };
    }
  }]);

  return ScrollHandler;
}();

exports.default = ScrollHandler;

/***/ }),