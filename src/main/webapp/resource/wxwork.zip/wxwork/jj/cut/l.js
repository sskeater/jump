
/* 11 */
/***/function (module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = Image;
	function Image() {
		var image = wx.createImage();

		return image;
	}

	/***/
},