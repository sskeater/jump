
/* 38 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var QueryCtrl = function () {
  function QueryCtrl(game) {
    _classCallCheck(this, QueryCtrl);

    this.game = game;
    this.model = this.game.gameModel;
    this.gameCtrl = this.game.gameCtrl;
  }

  _createClass(QueryCtrl, [{
    key: 'identifyMode',
    value: function identifyMode(options) {
      // if (options.scene == 1086 || options.scene == 1087) {
      //   this.model.setIsFromWn(1)
      // } else {
      //   this.model.setIsFromWn(0)
      // }

      if (!!options.query && options.query.hasOwnProperty('mode')) {
        switch (options.query.mode) {
          case 'groupShare':
            if (options.shareTicket) {
              this.model.setMode('groupShare');
            } else {
              this.gameCtrl.identifyModeErr('获取群信息失败');
              this.model.setMode('single');
            }
            break;
          case 'battle':
            if (options.query.pkId) {
              this.model.setMode('battle');
            } else {
              this.gameCtrl.identifyModeErr('获取PK信息失败');
              this.model.setMode('single');
            }
            break;
          case 'observe':
            if (options.query.gameId) {

              // gameId存session里！！！！！切记不看的时候关闭链接，清空gameId
              // Session.setGameId(options.query.gameId)
              this.model.setMode('observe');
            } else {
              this.gameCtrl.identifyModeErr('获取围观信息失败');
              this.model.setMode('single');
            }
            break;
          default:
            this.model.setMode('single');
            break;
        }
      } else {
        this.model.setMode('single');
      }
    }
  }]);

  return QueryCtrl;
}();

exports.default = QueryCtrl;

/***/ }),