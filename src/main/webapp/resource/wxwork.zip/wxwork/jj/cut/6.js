
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Session = function () {
  function Session() {
    _classCallCheck(this, Session);
  }

  _createClass(Session, null, [{
    key: 'init',
    value: function init() {
      this.sessionId = '';
      this.gameId = '';
      this.gameTicket = '';
      this.serverConfig = '';
      this.shareTicket = '';
      this.pkId = '';
      this.serverConfig = '';
    }
  }, {
    key: 'setLoginState',
    value: function setLoginState(sessionId) {
      this.sessionId = sessionId;
    }
  }, {
    key: 'setGameId',
    value: function setGameId(gameId) {
      this.gameId = gameId;
    }
  }, {
    key: 'setGameTicket',
    value: function setGameTicket(gameTicket) {
      this.gameTicket = gameTicket;
    }
  }, {
    key: 'setServerConfig',
    value: function setServerConfig(config) {
      this.serverConfig = config;
    }
  }, {
    key: 'setShareTicket',
    value: function setShareTicket(ticket) {
      this.shareTicket = ticket;
    }
  }, {
    key: 'setPkId',
    value: function setPkId(id) {
      this.pkId = id;
    }
  }, {
    key: 'clearPkId',
    value: function clearPkId() {
      this.pkId = '';
    }
  }, {
    key: 'clearGameId',
    value: function clearGameId() {
      this.gameId = '';
    }
  }, {
    key: 'clearShareTicket',
    value: function clearShareTicket() {
      this.ShareTicket = '';
    }
  }, {
    key: 'clearGameTicket',
    value: function clearGameTicket() {
      this.gameTicket = '';
    }
  }, {
    key: 'setServerConfig',
    value: function setServerConfig(config) {
      this.serverConfig = config;
    }
  }]);

  return Session;
}();

exports.default = Session;

/***/ }),