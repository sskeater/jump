
/* 57 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _friction = __webpack_require__(56);

var _friction2 = _interopRequireDefault(_friction);

var _spring = __webpack_require__(58);

var _spring2 = _interopRequireDefault(_spring);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Scroll = function () {
  /***
   * Scroll combines Friction and Spring to provide the
   * classic "flick-with-bounce" behavior.
   */
  function Scroll(extent) {
    _classCallCheck(this, Scroll);

    this._extent = extent;
    this._friction = new _friction2.default(0.01);
    this._spring = new _spring2.default(1, 90, 20);
    this._startTime = 0;
    this._springing = false;
    this._springOffset = 0;
  }

  _createClass(Scroll, [{
    key: 'set',
    value: function set(x, v) {
      this._friction.set(x, v);

      // If we're over the extent or zero then start springing. Notice that we also consult
      // velocity because we don't want flicks that start in the overscroll to get consumed
      // by the spring.
      if (x > 0 && v >= 0) {
        this._springOffset = 0;
        this._springing = true;
        this._spring.snap(x);
        this._spring.setEnd(0);
      } else if (x < -this._extent && v <= 0) {
        this._springOffset = 0;
        this._springing = true;
        this._spring.snap(x);
        this._spring.setEnd(-this._extent);
      } else {
        this._springing = false;
      }
      this._startTime = new Date().getTime();
    }
  }, {
    key: 'x',
    value: function x(t) {
      if (!this._startTime) return 0;
      if (!t) t = (new Date().getTime() - this._startTime) / 1000.0;
      // We've entered the spring, use the value from there.
      if (this._springing) return this._spring.x() + this._springOffset;
      // We're still in friction.
      var x = this._friction.x(t);
      var dx = this.dx(t);
      // If we've gone over the edge the roll the momentum into the spring.
      // console.log('x: ', x, 'dx: ', dx, ' _extent:', this._extent, ' _springOffset: ', this._springOffset)
      if ( /*(x > 0 && dx >= 0) || */x < -this._extent && dx <= 0) {
        this._springing = true;
        this._spring.setEnd(0, dx);
        if (x < -this._extent) this._springOffset = -this._extent;else this._springOffset = 0;
        x = this._spring.x() + this._springOffset;
      }
      return x;
    }
  }, {
    key: 'dx',
    value: function dx(t) {
      var dx = 0;

      if (this._lastTime === t) {
        dx = this._lastDx;
      } else if (this._springing) {
        dx = this._spring.dx(t);
      } else {
        dx = this._friction.dx(t);
      }

      this._lastTime = t;
      this._lastDx = dx;
      return dx;
    }
  }, {
    key: 'done',
    value: function done() {
      if (this._springing) return this._spring.done();else return this._friction.done();
    }
  }]);

  return Scroll;
}();

exports.default = Scroll;

/***/ }),