
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _singleStartPage = __webpack_require__(54);

var _singleStartPage2 = _interopRequireDefault(_singleStartPage);

var _singleGamePage = __webpack_require__(53);

var _singleGamePage2 = _interopRequireDefault(_singleGamePage);

var _singleGameOverPage = __webpack_require__(52);

var _singleGameOverPage2 = _interopRequireDefault(_singleGameOverPage);

var _singleFriendRankPage = __webpack_require__(51);

var _singleFriendRankPage2 = _interopRequireDefault(_singleFriendRankPage);

var _shareApp = __webpack_require__(7);

var _network = __webpack_require__(3);

var _network2 = _interopRequireDefault(_network);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var singleCtrl = function () {
  function singleCtrl(game, modeCtrl) {
    _classCallCheck(this, singleCtrl);

    this.name = 'single';
    this.game = game;
    this.gameCtrl = this.game.gameCtrl;
    this.model = this.game.gameModel;
    this.view = this.game.gameView;
    this.modeCtrl = modeCtrl;
    this.netWorkCtrl = this.gameCtrl.netWorkCtrl;
    this.gameSocket = this.game.gameSocket;

    this.startPage = new _singleStartPage2.default(game);
    this.gamePage = new _singleGamePage2.default(game);
    this.gameOverPage = new _singleGameOverPage2.default(game);
    this.friendRankPage = new _singleFriendRankPage2.default(game);
    this.currentPage = null;
    this.lastPage = null;

    this.socketTimeout = null;
  }

  _createClass(singleCtrl, [{
    key: 'init',
    value: function init(options) {
      this.startPage.show();
      this.model.setStage(this.startPage.name);
      this.currentPage = this.startPage;
    }
  }, {
    key: 'clickStart',
    value: function clickStart() {
      this.hideCurrentPage();
      this.gamePage.show();
      this.game.replayGame();
      this.model.setStage(this.gamePage.name);
      this.currentPage = this.gamePage;
    }
  }, {
    key: 'showGameOverPage',
    value: function showGameOverPage() {
      this.hideCurrentPage();
      this.gameOverPage.show();

      // 清空上次留存的pkId
      this.model.clearPkId();
      this.model.setStage(this.gameOverPage.name);
      this.currentPage = this.gameOverPage;
    }
  }, {
    key: 'gameOverClickReplay',
    value: function gameOverClickReplay() {
      this.clickStart();
    }
  }, {
    key: 'showFriendRank',
    value: function showFriendRank() {
      this.lastPage = this.currentPage;
      this.hideCurrentPage();
      this.friendRankPage.show();
      this.model.setStage(this.friendRankPage.name);
      this.currentPage = this.friendRankPage;
    }
  }, {
    key: 'friendRankReturn',
    value: function friendRankReturn() {
      this.hideCurrentPage();
      this.lastPage.show();

      this.model.setStage(this.lastPage.name);
      this.currentPage = this.lastPage;
      // this.lastPage = null
    }
  }, {
    key: 'shareGroupRank',
    value: function shareGroupRank() {
      var _this = this;

      (0, _shareApp.shareGroupRank)(function (success, isGroup) {
        _this.gameCtrl.afterShareGroupRank(success, isGroup);
      });
    }
  }, {
    key: 'clickRank',
    value: function clickRank() {
      this.showFriendRank();
    }
  }, {
    key: 'shareBattleCard',
    value: function shareBattleCard() {
      var _this2 = this;

      var sessionId = this.model.getSessionId();
      var currentScore = this.model.currentScore;
      var pkId = this.model.getPkId();
      if (!sessionId) {
        this.view.showNoSession();
        return;
      }

      if (!pkId) {
        _network2.default.createPK(currentScore).then(function () {
          _this2.afterHavePkId();
        }, function () {
          _this2.getPKErr();
        }).catch(function (err) {
          return console.log(err);
        });
      } else {
        this.afterHavePkId();
      }
    }
  }, {
    key: 'afterHavePkId',
    value: function afterHavePkId() {
      var _this3 = this;

      var pkId = this.model.getPkId();
      var score = this.model.currentScore;

      (0, _shareApp.shareBattle)(pkId, score, function (success, isGroup) {
        _this3.gameCtrl.afterShareBattle(success, isGroup);
      });
    }
  }, {
    key: 'getPKErr',
    value: function getPKErr() {
      this.view.showGetPkIdFail();
    }
  }, {
    key: 'shareObservCard',
    value: function shareObservCard() {
      this.gamePage.hideLookersShare();
      this.model.setStage('loading');
      wx.showLoading();
      var sessionId = this.model.getSessionId();
      if (!sessionId) {
        this.netWorkCtrl.netWorkLogin(this.afterLogin.bind(this));
      } else {
        this.afterLogin(true);
      }
    }
  }, {
    key: 'afterLogin',
    value: function afterLogin(success) {
      var _this4 = this;

      if (success) {
        // 连接socket和请求gameId
        _network2.default.requestCreateGame(function (success, res) {
          if (success) {
            _this4.model.setGameId(res.data.game_id);
            _this4.model.setGameTicket(res.data.up_op_ticket);
            _this4.shareObservCardA();
          } else {
            _this4.shareObservCardFail(res);
          }
        });
      } else {
        this.shareObservCardFail();
      }
    }
  }, {
    key: 'shareObservCardFail',
    value: function shareObservCardFail(res) {

      // 提示wording弹窗
      this.view.showShareObserveCardFail(res);

      // 清理gameId，gameTicket
      this.model.clearGameId();
      this.model.clearGameTicket();

      // 切回stage loading -> game
      if (this.model.stage == 'loading') {
        this.model.setStage('game');
      }

      // 清除定时器
      this.clearSocketTimeout();

      // 关闭socket 回到游戏页面
      this.gameSocket.close();

      // 清除wx.showloading
      wx.hideLoading();
    }
  }, {
    key: 'shareObservCardA',
    value: function shareObservCardA() {
      this.socketTimeout = setTimeout(this.shareObservCardFail.bind(this), 5000);

      /**
       * 连接网络
       * socket连接上自动joingame，中间出错，直接调用分享失败,关闭socket
       */
      this.gameSocket.connectSocket();
    }
  }, {
    key: 'socketJoinSuccess',
    value: function socketJoinSuccess(success) {
      wx.hideLoading();
      if (success) {

        // 取消定时器
        this.clearSocketTimeout();
        this.shareObservCardB();
      } else {
        this.shareObservCardFail();
      }
    }
  }, {
    key: 'shareObservCardB',
    value: function shareObservCardB() {
      var _this5 = this;

      (0, _shareApp.shareObserve)(function (success, num) {
        if (!!success) {
          _this5.gameCtrl.afterShareObserveCard(num);
        }
        setTimeout(function () {
          // console.log('!!!!!shareObservCardB,stage', this.model.stage)
          if (_this5.model.stage == 'loading') {
            _this5.model.setStage('game');
          }
          _this5.modeCtrl.singleChangeToPlayer();
          _this5.currentPage = null;
        }, 50);
      });
    }
  }, {
    key: 'clearSocketTimeout',
    value: function clearSocketTimeout() {
      if (this.socketTimeout != null) {
        clearTimeout(this.socketTimeout);
        this.socketTimeout = null;
      }
    }
  }, {
    key: 'wxOnhide',
    value: function wxOnhide() {
      return;
    }
  }, {
    key: 'wxOnshow',
    value: function wxOnshow() {
      return;
    }
  }, {
    key: 'destroy',
    value: function destroy() {
      this.hideCurrentPage();
      this.currentPage = null;
      this.model.setStage('');
      // 清理gameId，gameTicket
      this.model.clearGameId();
      this.model.clearGameTicket();

      // 清除定时器
      this.clearSocketTimeout();

      this.game.resetScene();
    }
  }, {
    key: 'hideCurrentPage',
    value: function hideCurrentPage() {
      if (this.currentPage) {
        this.currentPage.hide();
      }
    }
  }]);

  return singleCtrl;
}();

exports.default = singleCtrl;

/***/ }),