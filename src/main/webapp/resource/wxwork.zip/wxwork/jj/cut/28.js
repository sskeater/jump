
/* 28 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _three = __webpack_require__(1);

var THREE = _interopRequireWildcard(_three);

var _lookers = __webpack_require__(45);

var _lookers2 = _interopRequireDefault(_lookers);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var viewer = function () {
  function viewer(camera) {
    _classCallCheck(this, viewer);

    this.num = 0;
    this.list = [];
    this.imgPlanes = [];
    this.camera = camera;
    this.lookers = new _lookers2.default({ camera: camera });
    this.isOpen = false;
  }

  _createClass(viewer, [{
    key: 'peopleCome',
    value: function peopleCome(data) {

      var index = this.list.findIndex(function (el) {
        if (el) {
          return el.audience_openid == data.audience_openid;
        } else {
          return false;
        }
      });

      // 如果存在就返回
      if (index > -1) {
        return;
      }

      this.list.push(data);
      this.num++;
      if (this.isOpen) {
        this.showAvatar();
      }
    }
  }, {
    key: 'peopleOut',
    value: function peopleOut(data) {
      var index = this.list.findIndex(function (el) {
        if (el) {
          return el.audience_openid == data.audience_openid;
        } else {
          return false;
        }
      });

      // 没找到就算了
      if (index < 0) {
        return;
      }

      this.num = this.num - 1 < 0 ? 0 : this.num - 1;
      this.list.splice(index, 1);

      if (this.isOpen) {
        this.showAvatar();
      }
    }
  }, {
    key: 'showAvatar',
    value: function showAvatar() {
      if (this.num > 0) {

        var avatar = [];
        for (var i = 1; i < 4; i++) {
          if (this.list.length - i >= 0) {
            avatar.unshift(this.list[this.list.length - i].audience_headimg);
          }
        }
        this.lookers.showLookers({
          avaImg: true,
          icon: true,
          wording: false,
          num: this.num,
          avatar: avatar
        });
      } else {
        this.lookers.showLookers({
          avaImg: false,
          icon: true,
          wording: false
        });
      }
    }
  }, {
    key: 'open',
    value: function open() {
      this.isOpen = true;
      this.showAvatar();
    }
  }, {
    key: 'close',
    value: function close() {
      this.isOpen = false;
      this.hideAll();
    }
  }, {
    key: 'reset',
    value: function reset() {
      this.num = 0;
      this.list = [];
      this.lookers.hideLookers();
    }
  }, {
    key: 'hideAll',
    value: function hideAll() {
      this.lookers.hideLookers();
    }
  }]);

  return viewer;
}();
// {
//   udience_cmd: 0
//   audience_headimg: "http://wx.qlogo.cn/mmhead/Q3auHgzwzM4zFTRfibLzc9yiao5pcYygKRf3BKMYLiaEc8eavxSjEnIIA/0"
//   audience_nickname: "荣钦， …"
//   audience_openid: "ofCYP0eere2xI5Nyxw5Suq5yxS_g"
//   cmd: 108
//   game_id: "2352595985513730"
// }


exports.default = viewer;

/***/ }),