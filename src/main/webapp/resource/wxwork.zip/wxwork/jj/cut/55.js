
/* 55 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
	value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Report = function () {
	function Report(options) {
		_classCallCheck(this, Report);
	}

	_createClass(Report, null, [{
		key: 'frameReport',
		value: function frameReport(type, frame) {
			var key = 0; // 默认值
			switch (type) {
				case 'iPhone5':
					key = 1;break;
				case 'iPhone5s':
					key = 2;break;
				case 'iPhone6':
					key = 3;break;
				case 'iPhone6s':
					key = 4;break;
				case 'iPhone6Plus':
					key = 5;break;
				case 'iPhone6sPlus':
					key = 6;break;
				case 'iPhone7':
					key = 7;break;
				case 'iPhone7s':
					key = 8;break;
				case 'iPhone7Plus':
					key = 9;break;
				case 'iPhone7sPlus':
					key = 10;break;
				case 'iPhone8':
					key = 11;break;
				case 'iPhone8Plus':
					key = 12;break;
				case 'iPhoneX':
					key = 13;break;
			}

			new Image().src = "https://mp.weixin.qq.com/mp/jsmonitor?idkey=58121_" + key * 3 + "_" + frame + ";58121_" + (key * 3 + 1) + "_1&t=" + Math.random();
		}
	}]);

	return Report;
}();

exports.default = Report;

/***/ }),